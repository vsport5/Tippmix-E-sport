import requests
import json
import re

print("🔬 MÉLYREHATÓ NYOMKERESÉS - NEM ADJUK FEL!")
print("="*70)

# 1. VIZSGÁLJUK MEG A MŰKÖDŐ API VÁLASZOKAT - LEHET BENNÜK HINT!
print("\n1️⃣ Működő API-k vizsgálata hint-ekért...")

season_id = 3015575
current_round = 28
match_id = 1390738446

# Full feed API - ez nagy, sok infót tartalmaz
try:
    print("\n   🔍 Full Feed API elemzése...")
    feed_url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{season_id}/{current_round}"
    feed_data = requests.get(feed_url, timeout=10).json()
    feed_str = json.dumps(feed_data, indent=2, ensure_ascii=False)
    
    # Keresünk URL-eket, endpoint neveket
    urls_in_feed = re.findall(r'https?://[^\s\"]+', feed_str)
    print(f"   📡 Talált URL-ek a feed-ben: {len(set(urls_in_feed))}")
    for url in list(set(urls_in_feed))[:5]:
        print(f"      • {url}")
    
    # Keresünk gyanús mezőneveket
    field_patterns = [
        r'"([^"]*prediction[^"]*)"',
        r'"([^"]*generated[^"]*)"',
        r'"([^"]*simulation[^"]*)"',
        r'"([^"]*seed[^"]*)"',
        r'"([^"]*outcome[^"]*)"',
    ]
    
    for pattern in field_patterns:
        matches = re.findall(pattern, feed_str, re.I)
        if matches:
            print(f"   🎯 Talált mezők: {matches[:3]}")
    
except Exception as e:
    print(f"   ❌ {e}")

# 2. COMPETITIONS API - nézzük meg RÉSZLETESEN
print("\n2️⃣ Competitions API TELJES elemzése...")
try:
    comp_url = "https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh"
    comp_data = requests.get(comp_url, timeout=5).json()
    
    # Keressünk bármilyen API URL-t vagy endpoint hint-et
    comp_str = json.dumps(comp_data, indent=2, ensure_ascii=False)
    
    # Minden kulcs kinyerése
    def get_all_keys(obj, prefix=""):
        keys = []
        if isinstance(obj, dict):
            for k, v in obj.items():
                full_key = f"{prefix}.{k}" if prefix else k
                keys.append(full_key)
                keys.extend(get_all_keys(v, full_key))
        elif isinstance(obj, list) and obj:
            keys.extend(get_all_keys(obj[0], prefix))
        return keys
    
    all_keys = get_all_keys(comp_data)
    interesting_keys = [k for k in all_keys if any(word in k.lower() for word in 
                        ['prediction', 'generated', 'simulation', 'seed', 'outcome', 'url', 'api', 'endpoint'])]
    
    if interesting_keys:
        print(f"   🎯 Érdekes kulcsok:")
        for key in interesting_keys[:10]:
            print(f"      • {key}")
    
except Exception as e:
    print(f"   ❌ {e}")

# 3. TIMINGS API részletes elemzése
print("\n3️⃣ Timings API teljes elemzése...")
try:
    time_url = "https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0"
    time_data = requests.get(time_url, timeout=5).json()
    time_str = json.dumps(time_data, indent=2, ensure_ascii=False)
    
    # Minden match objektum mezői
    if "timings" in time_data and time_data["timings"]:
        match = time_data["timings"][0]["matches"][0]
        print(f"   📋 Match objektum mezői:")
        for key in sorted(match.keys()):
            print(f"      • {key}: {match[key] if len(str(match[key])) < 50 else str(match[key])[:50]+'...'}")
    
except Exception as e:
    print(f"   ❌ {e}")

# 4. PRÓBÁLJUNK MÉG PÁROÁPOT ENDPOINT NEVET
print("\n4️⃣ További endpoint nevek próbálása...")
extra_endpoints = [
    "vfl_predictions",
    "vfl_pregenerated", 
    "vfl_simulation",
    "match_predictions",
    "match_simulation",
    "event_predictions",
    "fixture_predictions",
    "pre_results",
    "pregame_data",
    "match_data",
    "simulation_data",
    "rng_seed",
    "random_seed",
    "match_seed",
]

base = "https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/"
found_new = []

for endpoint in extra_endpoints:
    # Próbáljuk season/round-dal
    url = f"{base}{endpoint}/{season_id}/{current_round}"
    try:
        resp = requests.get(url, timeout=2)
        if resp.status_code == 200:
            try:
                data = resp.json()
                if "exception" not in str(data).lower():
                    print(f"   ✅ LEHET TALÁLAT: {endpoint}")
                    print(f"      URL: {url}")
                    found_new.append({"endpoint": endpoint, "url": url})
            except:
                pass
    except:
        pass

if found_new:
    print(f"\n🚨 ÚJ ENDPOINT-OK TALÁLVA: {len(found_new)}")
    for f in found_new:
        print(f"   {f['endpoint']}: {f['url']}")

# 5. MATCH ODDS API MINTÁJA - próbáljuk átírni predictions-re
print("\n5️⃣ Match Odds API minta vizsgálata...")
odds_url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_odds2/{match_id}"
print(f"   Working pattern: match_odds2/{{{match_id}}}")
print(f"   Próbáljuk: match_predictions/{{{match_id}}}, match_simulation/{{{match_id}}}, stb.")

# Már teszteltük ezeket, de még egyszer, biztos ami biztos
alternative_patterns = [
    f"{base}match_predictions/{match_id}",
    f"{base}match_pregenerated/{match_id}",  
    f"{base}match_simulation/{match_id}",
    f"{base}event_predictions/{match_id}",
    f"{base}predictions2/{match_id}",
    f"{base}predictions_data/{match_id}",
]

for url in alternative_patterns:
    try:
        resp = requests.get(url, timeout=2)
        if resp.status_code == 200:
            data = resp.json()
            if "exception" not in str(data).lower() and len(str(data)) > 200:
                print(f"   🚨 FOUND: {url}")
                with open(f"ALT_FOUND_{url.split('/')[-2]}_{match_id}.json", 'w') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
    except:
        pass

print("\n✅ Nyomkeresés befejezve!")
