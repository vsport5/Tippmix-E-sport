# main.py
# MÉLY API VÉGPONT KERESÉS - Hálózati forgalom figyelése
# Célja: fogadáshoz szükséges összes API végpont megtalálása

import time, re, json
from urllib.parse import urljoin, urlparse, parse_qs

SAVE_FILE_API = "api_endpoints.txt"
SAVE_FILE_BETTING = "betting_apis.txt"
SAVE_FILE_ALL = "all_network_urls.txt"
SAVE_FILE_DETAILED = "api_details.json"

RUN_TIME = 60  # Hosszabb várakozás, hogy minden API hívás lefusson
TARGET_PAGE = "https://vfscigaming.aitcloud.de/vflmshop/retail/index?channel=7&clientid=4997&lang=zh&screen=betradar_vflm_one_screen&style=scigamingcdn"

def save_urls(urls, fname):
    with open(fname, "w", encoding="utf-8") as f:
        for u in sorted(urls):
            f.write(u + "\n")
    print(f"✅ {len(urls)} URL mentve: {fname}")

def save_json(data, fname):
    with open(fname, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print(f"✅ Részletes adatok mentve: {fname}")

def is_betting_api(url, headers=None):
    """Fogadáshoz kapcsolódó API-k azonosítása"""
    betting_keywords = [
        r"odds",
        r"bet",
        r"wager",
        r"stake",
        r"match",
        r"fixture",
        r"event",
        r"game",
        r"result",
        r"score",
        r"market",
        r"settlement",
        r"h2h",
        r"head.*to.*head",
        r"statistics",
        r"stats",
        r"probability",
        r"team",
        r"league",
        r"season",
        r"schedule",
        r"live",
        r"feed",
        r"virtual",
        r"vfl",
        r"sportradar",
        r"betradar"
    ]
    
    for keyword in betting_keywords:
        if re.search(keyword, url, re.I):
            return True
    
    # Ellenőrizzük a headers-t is
    if headers:
        accept = headers.get("accept", "").lower()
        if "json" in accept or "xml" in accept:
            return True
    
    return False

def looks_like_static(url):
    """Statikus fájlok kiszűrése"""
    static_extensions = [
        r"\.js(\?|$)",
        r"\.css(\?|$)",
        r"\.png(\?|$)",
        r"\.jpg(\?|$)",
        r"\.jpeg(\?|$)",
        r"\.gif(\?|$)",
        r"\.svg(\?|$)",
        r"\.woff2?(\?|$)",
        r"\.ttf(\?|$)",
        r"\.eot(\?|$)",
        r"\.mp4(\?|$)",
        r"\.webm(\?|$)",
        r"\.ico(\?|$)"
    ]
    
    for ext in static_extensions:
        if re.search(ext, url, re.I):
            return True
    return False

def deep_scan_with_network_monitoring(target, run_time=RUN_TIME):
    """Selenium + CDP hálózati forgalom figyelés"""
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.common.by import By
    
    print("🔧 Chrome böngésző indítása hálózati figyeléssel...")
    options = Options()
    options.add_argument("--headless")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    
    # Engedélyezzük a logging-ot
    options.set_capability("goog:loggingPrefs", {"performance": "ALL"})
    
    network_data = []
    
    try:
        driver = webdriver.Chrome(options=options)
        
        # CDP parancsok engedélyezése
        driver.execute_cdp_cmd("Network.enable", {})
        driver.execute_cdp_cmd("Page.enable", {})
        
        print(f"🌐 Oldal betöltése: {target}")
        driver.get(target)
        
        print(f"⏳ Figyelés {run_time} másodpercig...")
        print("   (Várjuk, hogy az összes mérkőzés, odds és statisztika betöltődjön)")
        
        # Várakozás lépésekben, hogy figyeljük a folyamatot
        steps = 6
        step_time = run_time // steps
        for i in range(steps):
            time.sleep(step_time)
            print(f"   ... {(i+1) * step_time}s eltelt ...")
        
        print("📡 Hálózati logok gyűjtése...")
        
        # Performance logok elemzése
        logs = driver.get_log("performance")
        
        for entry in logs:
            try:
                log_entry = json.loads(entry["message"])
                message = log_entry.get("message", {})
                method = message.get("method", "")
                
                # Csak a hálózati kéréseket nézzük
                if method == "Network.requestWillBeSent":
                    params = message.get("params", {})
                    request = params.get("request", {})
                    url = request.get("url", "")
                    headers = request.get("headers", {})
                    
                    if url and not looks_like_static(url):
                        network_data.append({
                            "url": url,
                            "method": request.get("method", "GET"),
                            "headers": headers,
                            "timestamp": params.get("timestamp", 0)
                        })
                
                # Válaszokat is figyeljük
                elif method == "Network.responseReceived":
                    params = message.get("params", {})
                    response = params.get("response", {})
                    url = response.get("url", "")
                    
                    if url and not looks_like_static(url):
                        # Ellenőrizzük, hogy JSON/XML választ kaptunk-e
                        mime_type = response.get("mimeType", "")
                        if "json" in mime_type or "xml" in mime_type:
                            network_data.append({
                                "url": url,
                                "type": "response",
                                "mimeType": mime_type,
                                "status": response.get("status", 0)
                            })
            except Exception as e:
                continue
        
        # Oldal forráskódjából is keresünk
        page_source = driver.page_source
        print(f"📄 Oldal forrás hossza: {len(page_source)} karakter")
        
        # URL-ek keresése a forráskódban
        url_regex = re.compile(r'https?://[^\s\'\"<>]+', re.I)
        source_urls = set()
        for match in url_regex.findall(page_source):
            cleaned = match.rstrip('",;)')
            if not looks_like_static(cleaned):
                source_urls.add(cleaned)
        
        driver.quit()
        
        print(f"🔍 Hálózati logokból: {len(network_data)} bejegyzés")
        print(f"🔍 Oldal forrásból: {len(source_urls)} URL")
        
        return network_data, source_urls
        
    except Exception as e:
        print(f"❌ Hiba: {e}")
        try:
            driver.quit()
        except:
            pass
        return [], set()

def analyze_and_categorize(network_data, source_urls):
    """API-k elemzése és kategorizálása"""
    
    all_urls = set()
    betting_apis = set()
    api_details = []
    
    # Hálózati adatok feldolgozása
    for entry in network_data:
        url = entry.get("url", "")
        if not url:
            continue
        
        all_urls.add(url)
        
        # Betting API?
        headers = entry.get("headers", {})
        if is_betting_api(url, headers):
            betting_apis.add(url)
            
            # Részletes info
            api_details.append({
                "url": url,
                "type": "betting",
                "method": entry.get("method", "GET"),
                "detected_from": "network_log",
                "keywords": extract_keywords(url)
            })
    
    # Forrás URL-ek feldolgozása
    for url in source_urls:
        all_urls.add(url)
        
        if is_betting_api(url):
            betting_apis.add(url)
            
            if not any(d["url"] == url for d in api_details):
                api_details.append({
                    "url": url,
                    "type": "betting",
                    "detected_from": "page_source",
                    "keywords": extract_keywords(url)
                })
    
    return all_urls, betting_apis, api_details

def extract_keywords(url):
    """Kulcsszavak kinyerése az URL-ből"""
    keywords = []
    
    betting_terms = ["odds", "bet", "match", "event", "result", "score", 
                     "market", "settlement", "h2h", "stats", "team", 
                     "league", "season", "live", "feed", "virtual"]
    
    for term in betting_terms:
        if re.search(term, url, re.I):
            keywords.append(term)
    
    return keywords

def print_summary(all_urls, betting_apis, api_details):
    """Összefoglaló kiírása"""
    print("\n" + "=" * 60)
    print("📊 ÖSSZEFOGLALÓ")
    print("=" * 60)
    print(f"✅ Összes talált URL: {len(all_urls)}")
    print(f"🎯 Fogadáshoz kapcsolódó API-k: {len(betting_apis)}")
    
    if betting_apis:
        print("\n🎲 FOGADÁSI API VÉGPONTOK (első 10):")
        for i, url in enumerate(sorted(betting_apis)[:10], 1):
            print(f"  {i}. {url}")
    
    # Kategorizálás típus szerint
    categories = {}
    for detail in api_details:
        keywords = detail.get("keywords", [])
        for kw in keywords:
            if kw not in categories:
                categories[kw] = []
            categories[kw].append(detail["url"])
    
    if categories:
        print("\n📂 KATEGÓRIÁK:")
        for category, urls in sorted(categories.items()):
            print(f"  • {category.upper()}: {len(urls)} API")

def main():
    print("=" * 60)
    print("🔍 MÉLY API VÉGPONT KERESÉS")
    print("=" * 60)
    print("Fogadási rendszerhez szükséges API-k feltérképezése\n")
    
    # Hálózati forgalom figyelése
    network_data, source_urls = deep_scan_with_network_monitoring(TARGET_PAGE, RUN_TIME)
    
    if not network_data and not source_urls:
        print("⚠️ Nem sikerült adatot gyűjteni")
        return
    
    # Elemzés és kategorizálás
    print("\n📊 Adatok elemzése...")
    all_urls, betting_apis, api_details = analyze_and_categorize(network_data, source_urls)
    
    # Mentés
    print("\n💾 Fájlok mentése...")
    save_urls(all_urls, SAVE_FILE_ALL)
    save_urls(betting_apis, SAVE_FILE_BETTING)
    
    # API-k részletesen
    api_urls = set(d["url"] for d in api_details)
    save_urls(api_urls, SAVE_FILE_API)
    save_json(api_details, SAVE_FILE_DETAILED)
    
    # Összefoglaló
    print_summary(all_urls, betting_apis, api_details)
    
    print("\n📁 FÁJLOK:")
    print(f"  • {SAVE_FILE_BETTING} - Fogadási API-k ({len(betting_apis)} db)")
    print(f"  • {SAVE_FILE_API} - Összes API ({len(api_urls)} db)")
    print(f"  • {SAVE_FILE_ALL} - Minden URL ({len(all_urls)} db)")
    print(f"  • {SAVE_FILE_DETAILED} - Részletes elemzés (JSON)")

if __name__ == "__main__":
    main()
