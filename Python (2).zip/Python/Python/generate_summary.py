# generate_summary.py
# Összefoglaló generálása a scanelt API-kből

import json
from datetime import datetime

def generate_html_summary():
    """HTML összefoglaló generálása"""
    
    # Betöltjük a részletes adatokat
    try:
        with open('deep_api_details.json', 'r', encoding='utf-8') as f:
            api_details = json.load(f)
    except:
        api_details = []
    
    # Kategóriák számlálása
    categories = {}
    for api in api_details:
        for kw in api.get('keywords', []):
            categories[kw] = categories.get(kw, 0) + 1
    
    # HTML generálás
    html = """<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Scanner Összefoglaló</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
        }
        .container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
        }
        h1 {
            text-align: center;
            font-size: 3em;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .subtitle {
            text-align: center;
            font-size: 1.2em;
            opacity: 0.9;
            margin-bottom: 40px;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }
        .stat-card {
            background: rgba(255, 255, 255, 0.2);
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-number {
            font-size: 3em;
            font-weight: bold;
            margin: 10px 0;
        }
        .stat-label {
            font-size: 0.9em;
            opacity: 0.9;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .category-list {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 30px;
            margin-top: 30px;
        }
        .category-item {
            display: flex;
            justify-content: space-between;
            padding: 15px;
            margin: 10px 0;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            transition: all 0.3s;
        }
        .category-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(10px);
        }
        .category-name {
            font-weight: bold;
            text-transform: uppercase;
        }
        .category-count {
            background: rgba(255, 255, 255, 0.3);
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: bold;
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            opacity: 0.8;
            font-size: 0.9em;
        }
        a {
            color: #ffd700;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 API Scanner</h1>
        <div class="subtitle">Virtuális Sportfogadási Rendszer API Feltérképezés</div>
        
        <div class="stats">
            <div class="stat-card">
                <div class="stat-label">🎯 Összesen API</div>
                <div class="stat-number">""" + str(len(api_details)) + """</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">📂 Kategóriák</div>
                <div class="stat-number">""" + str(len(categories)) + """</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">⏱️ Scan idő</div>
                <div class="stat-number">10</div>
                <div class="stat-label" style="font-size: 0.7em;">PERC</div>
            </div>
        </div>
        
        <div class="category-list">
            <h2 style="text-align: center; margin-bottom: 30px;">📊 API Kategóriák</h2>
"""
    
    # Kategóriák hozzáadása
    for cat, count in sorted(categories.items(), key=lambda x: x[1], reverse=True)[:15]:
        html += f"""
            <div class="category-item">
                <span class="category-name">🔹 {cat.upper()}</span>
                <span class="category-count">{count} API</span>
            </div>
"""
    
    html += """
        </div>
        
        <div class="footer">
            <p>📄 <a href="MELYITETT_API_LINKEK.md">Részletes dokumentáció megtekintése</a></p>
            <p>🚀 Generálva: """ + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + """</p>
        </div>
    </div>
</body>
</html>
"""
    
    with open('index.html', 'w', encoding='utf-8') as f:
        f.write(html)
    
    print("✅ HTML összefoglaló generálva: index.html")
    print("🌐 A fájl megnyitható böngészőben!")

if __name__ == "__main__":
    generate_html_summary()
