import requests
import json

print("🎯 GYORS, CÉLZOTT TESZTELÉS - A LEGVALÓSZÍNŰBB KOMBÓK")
print("="*70)

# Aktuális adatok
comp_url = "https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh"
comp_data = requests.get(comp_url, timeout=5).json()
season_id = comp_data["next_competitions"][0]["competition_id"]

time_url = "https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0"
time_data = requests.get(time_url, timeout=5).json()
current_round = time_data["timings"][0]["matches"][0]["matchset_nr"]
match_id = time_data["timings"][0]["matches"][0]["id"]

print(f"Season: {season_id}, Round: {current_round}, Match: {match_id}\n")

# A legfontosabb endpoint-ok
critical_endpoints = ["predictions", "pregenerated", "simulation", "generated"]

# URL sablonok (a working API-k mintájára)
url_templates = [
    # Gismo pattern (mint match_odds2, vfl_event_fullfeed)
    "https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/{endpoint}/{season_id}/{round}",
    "https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/{endpoint}/{match_id}",
    "https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/{endpoint}/{season_id}",
    "https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_{endpoint}/{season_id}/{round}",
    "https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_{endpoint}/{match_id}",
    
    # Direct data pattern (mint vf_livescore)
    "https://vfdirectdata.live.vsports.cloud//14562/scigamingscigamingcdn/zh/Europe:Berlin/vf_{endpoint}/{season_id}/league/{round}",
    "https://vfdirectdata.live.vsports.cloud//14562/scigamingscigamingcdn/zh/Europe:Berlin/{endpoint}/{season_id}/{round}",
    
    # Widget pattern
    "https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.{endpoint}/vswidgets/",
    "https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.{endpoint}/vswidgets/",
]

found = []

for endpoint in critical_endpoints:
    print(f"\n{'='*70}")
    print(f"🔍 {endpoint.upper()}")
    print(f"{'='*70}")
    
    for template in url_templates:
        url = template.format(
            endpoint=endpoint,
            season_id=season_id,
            round=current_round,
            match_id=match_id
        )
        
        try:
            resp = requests.get(url, timeout=3)
            
            if resp.status_code == 200:
                # Ellenőrizzük, nem exception-e
                try:
                    data = resp.json()
                    is_exception = False
                    
                    if isinstance(data, dict) and "doc" in data:
                        if isinstance(data["doc"], list) and len(data["doc"]) > 0:
                            if data["doc"][0].get("event") == "exception":
                                is_exception = True
                    
                    if not is_exception and len(resp.text) > 200:
                        print(f"\n🚨🚨🚨 TALÁLAT! 🚨🚨🚨")
                        print(f"URL: {url}")
                        print(f"Méret: {len(resp.text)} karakter")
                        print(f"Preview: {json.dumps(data, indent=2)[:400]}")
                        
                        filename = f"SUCCESS_{endpoint}_{season_id}_{current_round}.json"
                        with open(filename, 'w', encoding='utf-8') as f:
                            json.dump(data, f, indent=2, ensure_ascii=False)
                        print(f"💾 MENTVE: {filename}")
                        
                        found.append({"endpoint": endpoint, "url": url, "file": filename})
                        
                except:
                    # Nem JSON, de lehet érdekes
                    if len(resp.text) > 200 and "exception" not in resp.text.lower():
                        print(f"\n⚠️ Nem JSON válasz, de érdekes: {url}")
                        print(f"Első 200 char: {resp.text[:200]}")
                        
        except:
            pass

print(f"\n{'='*70}")
print(f"EREDMÉNY: {len(found)} sikeres API talált!")
print(f"{'='*70}")

if found:
    for f in found:
        print(f"✅ {f['endpoint']}: {f['url']}")
else:
    print("❌ Egyik próbálkozás sem vezetett eredményre")

with open('quick_test_results.json', 'w', encoding='utf-8') as f:
    json.dump(found, f, indent=2, ensure_ascii=False)
