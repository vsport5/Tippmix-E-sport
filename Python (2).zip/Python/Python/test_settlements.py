
import requests
import json
from datetime import datetime

def test_settlements_api():
    """Settlements API tesztelése különböző paraméterekkel"""
    
    print("=" * 70)
    print("🔍 SETTLEMENTS API TESZTELÉS")
    print("=" * 70)
    
    # Aktuális szezon és forduló lekérése
    comp_url = "https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh"
    comp_data = requests.get(comp_url).json()
    season_id = comp_data["next_competitions"][0]["competition_id"]
    
    time_url = "https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0"
    time_data = requests.get(time_url).json()
    current_round = time_data["timings"][0]["matches"][0]["matchset_nr"]
    match_id = time_data["timings"][0]["matches"][0]["id"]
    
    print(f"\n📍 Aktuális adatok:")
    print(f"   Szezon: {season_id}")
    print(f"   Forduló: {current_round}")
    print(f"   Match ID: {match_id}")
    
    # Különböző settlements URL variációk
    base_urls = [
        "https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/settlements",
        f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/settlements/{season_id}",
        f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/settlements/{season_id}/{current_round}",
        f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/settlements/{match_id}",
        f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_settlements/{match_id}",
        f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_settlements/{season_id}/{current_round}",
    ]
    
    results = []
    
    for i, url in enumerate(base_urls, 1):
        print(f"\n🔍 Teszt #{i}: {url}")
        
        try:
            resp = requests.get(url, timeout=10)
            
            print(f"   Status: {resp.status_code}")
            
            if resp.status_code == 200:
                try:
                    data = resp.json()
                    print(f"   ✅ MŰKÖDIK! JSON válasz érkezett")
                    print(f"   Méret: {len(json.dumps(data))} karakter")
                    
                    # Keresünk settlement/result mezőket
                    data_str = json.dumps(data, indent=2)
                    
                    keywords_found = []
                    for keyword in ['settlement', 'settled', 'result', 'outcome', 'winner', 'final']:
                        if keyword in data_str.lower():
                            keywords_found.append(keyword)
                    
                    if keywords_found:
                        print(f"   🚨 TARTALMAZ: {', '.join(keywords_found)}")
                    
                    results.append({
                        "url": url,
                        "status": "SUCCESS",
                        "data": data,
                        "keywords": keywords_found
                    })
                    
                    # Mentés
                    filename = f"settlements_test_{i}.json"
                    with open(filename, "w", encoding="utf-8") as f:
                        json.dump(data, f, indent=2, ensure_ascii=False)
                    print(f"   💾 Mentve: {filename}")
                    
                except:
                    print(f"   ⚠️ Nem JSON válasz")
                    print(f"   Első 200 karakter: {resp.text[:200]}")
                    
                    results.append({
                        "url": url,
                        "status": "NON_JSON",
                        "response": resp.text[:500]
                    })
            else:
                print(f"   ❌ Hiba: {resp.status_code}")
                results.append({
                    "url": url,
                    "status": f"ERROR_{resp.status_code}"
                })
                
        except Exception as e:
            print(f"   ❌ Exception: {e}")
            results.append({
                "url": url,
                "status": "EXCEPTION",
                "error": str(e)
            })
    
    # Összefoglaló
    print("\n" + "=" * 70)
    print("📊 ÖSSZEFOGLALÓ")
    print("=" * 70)
    
    successes = [r for r in results if r["status"] == "SUCCESS"]
    
    if successes:
        print(f"\n✅ SIKERES TALÁLT: {len(successes)} db")
        for res in successes:
            print(f"\n🎯 {res['url']}")
            if res.get('keywords'):
                print(f"   Kulcsszavak: {', '.join(res['keywords'])}")
    else:
        print("\n❌ Egyetlen settlement API sem működött a tesztelt paraméterekkel")
        print("\n💡 Következő lépések:")
        print("   1. Nézd meg a full_feed API-t részletesen")
        print("   2. Keress más settlement endpoint neveket")
        print("   3. Próbálj Widget API-kat (resolvedmarkets)")
    
    # Mentés
    with open("settlements_test_results.json", "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    
    print("\n💾 Teljes eredmények: settlements_test_results.json")

if __name__ == "__main__":
    test_settlements_api()
