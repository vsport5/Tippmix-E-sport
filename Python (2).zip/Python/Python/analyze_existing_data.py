
# analyze_existing_data.py
# Meglévő API-k MÉLY ELEMZÉSE - Rejtett mezők, settlement, prediction keresése

import requests
import json
import re
from datetime import datetime

def deep_analyze_competitions_api():
    """Competitions API mély elemzése"""
    print("=" * 70)
    print("🔍 COMPETITIONS API ELEMZÉSE")
    print("=" * 70)
    
    url = "https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh"
    
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
        
        # Teljes JSON kiírása
        full_json = json.dumps(data, indent=2, ensure_ascii=False)
        
        # Keresünk érdekes mezőket
        interesting_fields = []
        
        # Settlement/Result keresés
        if re.search(r'settlement|result|outcome|winner|final', full_json, re.I):
            interesting_fields.append("SETTLEMENT/RESULT mezők találva!")
        
        # Prediction/Probability
        if re.search(r'prediction|probability|forecast|odds', full_json, re.I):
            interesting_fields.append("PREDICTION/PROBABILITY mezők találva!")
        
        # Generated/Seed
        if re.search(r'generated|seed|random|simulation', full_json, re.I):
            interesting_fields.append("GENERATED/SIMULATION adatok találva!")
        
        print("\n📊 Elemzés:")
        print(f"   • Válasz méret: {len(full_json)} karakter")
        print(f"   • Szezonok száma: {len(data.get('next_competitions', [])) + len(data.get('past_competitions', []))}")
        
        if interesting_fields:
            print("\n✅ ÉRDEKES MEZŐK:")
            for field in interesting_fields:
                print(f"   • {field}")
        
        # Részletes kiírás
        print("\n📄 TELJES VÁLASZ (első 1000 karakter):")
        print(full_json[:1000])
        
        # Mentés
        with open("competitions_full_response.json", "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        print("\n💾 Teljes válasz mentve: competitions_full_response.json")
        
        return data
        
    except Exception as e:
        print(f"❌ Hiba: {e}")
        return None

def deep_analyze_timings_api():
    """Timings API mély elemzése"""
    print("\n" + "=" * 70)
    print("🔍 TIMINGS API ELEMZÉSE")
    print("=" * 70)
    
    url = "https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0"
    
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
        
        full_json = json.dumps(data, indent=2, ensure_ascii=False)
        
        print("\n📊 Elemzés:")
        print(f"   • Válasz méret: {len(full_json)} karakter")
        
        # Phases elemzése
        if "timings" in data:
            for phase in data["timings"]:
                phase_name = phase.get("phase_name", "unknown")
                match_count = len(phase.get("matches", []))
                print(f"   • Phase: {phase_name} - {match_count} mérkőzés")
        
        # Keresünk érdekes mezőket
        interesting_patterns = [
            (r'result', "RESULT mezők"),
            (r'outcome', "OUTCOME mezők"),
            (r'settlement', "SETTLEMENT mezők"),
            (r'prediction', "PREDICTION mezők"),
            (r'probability', "PROBABILITY mezők"),
            (r'generated|seed', "GENERATED/SEED mezők"),
            (r'winner|final', "WINNER/FINAL mezők")
        ]
        
        found = []
        for pattern, name in interesting_patterns:
            if re.search(pattern, full_json, re.I):
                found.append(name)
        
        if found:
            print("\n✅ ÉRDEKES MEZŐK:")
            for item in found:
                print(f"   • {item}")
        
        print("\n📄 TELJES VÁLASZ (első 1500 karakter):")
        print(full_json[:1500])
        
        # Mentés
        with open("timings_full_response.json", "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        print("\n💾 Teljes válasz mentve: timings_full_response.json")
        
        return data
        
    except Exception as e:
        print(f"❌ Hiba: {e}")
        return None

def deep_analyze_fullfeed_api():
    """Full Feed API mély elemzése - EZ A LEGÉRDEKESEBB!"""
    print("\n" + "=" * 70)
    print("🔍 FULL FEED API ELEMZÉSE")
    print("=" * 70)
    
    # Lekérjük az aktuális szezont
    comp = requests.get("https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh").json()
    season_id = comp["next_competitions"][0]["competition_id"]
    
    # Lekérjük a timings-ot az aktuális fordulóért
    timings = requests.get("https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0").json()
    round_nr = timings["timings"][0]["matches"][0]["matchset_nr"]
    
    url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{season_id}/{round_nr}"
    
    print(f"\n📍 Aktuális: Szezon {season_id}, Forduló {round_nr}")
    
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
        
        full_json = json.dumps(data, indent=2, ensure_ascii=False)
        
        print("\n📊 Elemzés:")
        print(f"   • Válasz méret: {len(full_json)} karakter ({len(full_json)/1024:.1f} KB)")
        
        # Keresünk MINDEN érdekes mezőt
        all_keys = set()
        
        def extract_all_keys(obj, prefix=""):
            """Rekurzívan kinyeri az összes kulcsot"""
            if isinstance(obj, dict):
                for key, value in obj.items():
                    full_key = f"{prefix}.{key}" if prefix else key
                    all_keys.add(full_key)
                    extract_all_keys(value, full_key)
            elif isinstance(obj, list) and obj:
                extract_all_keys(obj[0], prefix)
        
        extract_all_keys(data)
        
        print(f"   • Összes mező: {len(all_keys)}")
        
        # Érdekes kulcsok
        interesting_keywords = [
            'result', 'outcome', 'settlement', 'winner', 'final',
            'prediction', 'probability', 'forecast', 'odds',
            'generated', 'seed', 'random', 'simulation',
            'score', 'goal', 'stats', 'form', 'h2h',
            'config', 'metadata', 'internal', 'debug'
        ]
        
        interesting_keys = []
        for key in all_keys:
            for keyword in interesting_keywords:
                if keyword in key.lower():
                    interesting_keys.append(key)
                    break
        
        if interesting_keys:
            print(f"\n✅ ÉRDEKES MEZŐK ({len(interesting_keys)} db):")
            for key in sorted(interesting_keys)[:30]:
                print(f"   • {key}")
            if len(interesting_keys) > 30:
                print(f"   ... és még {len(interesting_keys) - 30} mező")
        
        # Keresünk specifikus mintákat a JSON-ben
        patterns_to_find = {
            'settlement': r'"settlement[^"]*":\s*[^,}\]]+',
            'result': r'"result[^"]*":\s*[^,}\]]+',
            'outcome': r'"outcome[^"]*":\s*[^,}\]]+',
            'prediction': r'"prediction[^"]*":\s*[^,}\]]+',
            'generated': r'"generated[^"]*":\s*[^,}\]]+',
            'seed': r'"seed[^"]*":\s*[^,}\]]+',
        }
        
        print("\n🔎 SPECIFIKUS MINTA KERESÉS:")
        for name, pattern in patterns_to_find.items():
            matches = re.findall(pattern, full_json, re.I)
            if matches:
                print(f"\n   {name.upper()} találatok ({len(matches)} db):")
                for match in matches[:5]:
                    print(f"      {match}")
                if len(matches) > 5:
                    print(f"      ... és még {len(matches) - 5} találat")
        
        # Első 3000 karakter kiírása
        print("\n📄 TELJES VÁLASZ (első 3000 karakter):")
        print(full_json[:3000])
        
        # Mentés
        filename = f"fullfeed_s{season_id}_r{round_nr}.json"
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        print(f"\n💾 Teljes válasz mentve: {filename}")
        
        return data
        
    except Exception as e:
        print(f"❌ Hiba: {e}")
        return None

def deep_analyze_odds_api():
    """Odds API mély elemzése - Szorzók + rejtett adatok"""
    print("\n" + "=" * 70)
    print("🔍 ODDS API ELEMZÉSE")
    print("=" * 70)
    
    # Lekérjük az első match ID-t
    timings = requests.get("https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0").json()
    match_id = timings["timings"][0]["matches"][0]["id"]
    
    url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_odds2/{match_id}"
    
    print(f"\n📍 Match ID: {match_id}")
    
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
        
        full_json = json.dumps(data, indent=2, ensure_ascii=False)
        
        print("\n📊 Elemzés:")
        print(f"   • Válasz méret: {len(full_json)} karakter")
        
        # Keresünk érdekes adatokat
        if re.search(r'settlement|result|outcome', full_json, re.I):
            print("   ✅ SETTLEMENT/RESULT adatok TALÁLVA!")
        
        if re.search(r'probability|prediction', full_json, re.I):
            print("   ✅ PROBABILITY/PREDICTION adatok TALÁLVA!")
        
        print("\n📄 TELJES VÁLASZ (első 2000 karakter):")
        print(full_json[:2000])
        
        # Mentés
        with open(f"odds_match_{match_id}.json", "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        print(f"\n💾 Teljes válasz mentve: odds_match_{match_id}.json")
        
        return data
        
    except Exception as e:
        print(f"❌ Hiba: {e}")
        return None

def test_hidden_endpoints():
    """Rejtett endpoint-ok tesztelése"""
    print("\n" + "=" * 70)
    print("🔍 REJTETT ENDPOINT-OK KERESÉSE")
    print("=" * 70)
    
    base_urls = [
        "https://vf.live.vsports.cloud/vflmshop/mobile/",
        "https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/"
    ]
    
    endpoints = [
        "settlements",
        "results",
        "outcomes",
        "predictions",
        "probabilities",
        "generated_data",
        "seeds",
        "metadata",
        "config",
        "internal",
        "admin",
        "debug",
        "simulation_results",
        "pre_generated",
        "fixture_outcomes"
    ]
    
    print("\n🔎 Tesztelés...")
    found = []
    
    for base in base_urls:
        for endpoint in endpoints:
            url = base + endpoint
            try:
                resp = requests.get(url, timeout=3)
                if resp.status_code == 200:
                    print(f"   ✅ TALÁLT: {url}")
                    found.append(url)
                    
                    # Mentés
                    with open(f"hidden_{endpoint}.json", "w", encoding="utf-8") as f:
                        try:
                            f.write(resp.text)
                        except:
                            f.write(str(resp.content))
            except:
                pass
    
    if found:
        print(f"\n🎯 TALÁLAT: {len(found)} rejtett endpoint!")
        for url in found:
            print(f"   • {url}")
    else:
        print("\n⚠️ Nem találtunk rejtett endpoint-okat")
    
    return found

def main():
    print("=" * 70)
    print("🎯 MEGLÉVŐ API-K MÉLYANALÍZISE")
    print("=" * 70)
    print("Rejtett mezők, settlement, prediction, generated adatok keresése\n")
    
    # 1. Competitions API
    deep_analyze_competitions_api()
    
    # 2. Timings API
    deep_analyze_timings_api()
    
    # 3. Full Feed API - A LEGFONTOSABB!
    deep_analyze_fullfeed_api()
    
    # 4. Odds API
    deep_analyze_odds_api()
    
    # 5. Rejtett endpoint-ok
    test_hidden_endpoints()
    
    print("\n" + "=" * 70)
    print("✅ ELEMZÉS BEFEJEZVE!")
    print("=" * 70)
    print("\n📁 MENTETT FÁJLOK:")
    print("   • competitions_full_response.json")
    print("   • timings_full_response.json")
    print("   • fullfeed_s{SEASON}_r{ROUND}.json")
    print("   • odds_match_{MATCH_ID}.json")
    print("   • hidden_*.json (ha találtunk)")

if __name__ == "__main__":
    main()
