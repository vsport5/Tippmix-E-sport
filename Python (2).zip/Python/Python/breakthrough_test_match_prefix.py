import requests
import json

print("🔥🔥🔥 ÁTTÖRÉS TESZT - match_ PREFIX! 🔥🔥🔥")
print("="*70)
print("User rájött: match_events és match_timeline működik!")
print("Most teszteljük az ÖSSZES API-t ezzel a mintával!\n")

# Aktuális match ID-k
comp_data = requests.get("https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh").json()
season_id = comp_data["next_competitions"][0]["competition_id"]

time_data = requests.get("https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0").json()
current_round = time_data["timings"][0]["matches"][0]["matchset_nr"]

# Gyűjtsünk match ID-kat
match_ids = []
for timing in time_data.get("timings", []):
    for match in timing.get("matches", []):
        match_ids.append(match["id"])

print(f"Szezon: {season_id}, Forduló: {current_round}")
print(f"Match ID-k: {len(match_ids)} db")
print(f"Tesztelendő match ID: {match_ids[0] if match_ids else 'N/A'}\n")

# KRITIKUS API NEVEK (a match_ prefix NÉLKÜL!)
api_names = [
    "predictions",
    "pregenerated",
    "generated", 
    "simulation",
    "settlements",
    "results",
    "outcomes",
    "probabilities",
    "calculator",
    "fixture_results",
    "match_outcomes",
    "event_settlements",
    "admin",
    "internal",
    "debug",
    "config",
    "metadata",
    "resolved",
    "timeline",  # már tudjuk hogy ez működik
    "events",    # már tudjuk hogy ez működik
    "odds2",     # tudjuk hogy match_odds2 létezik
]

base = "https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/"

successes = []
test_match_id = match_ids[0] if match_ids else 1390738374

print("="*70)
print("🎯 TESZTELÉS KEZDÉSE")
print("="*70)

for api_name in api_names:
    url = f"{base}match_{api_name}/{test_match_id}"
    
    try:
        resp = requests.get(url, timeout=3)
        
        if resp.status_code == 200:
            try:
                data = resp.json()
                data_str = json.dumps(data, indent=2, ensure_ascii=False)
                
                # Ellenőrizzük hogy NEM exception
                is_valid = True
                if "exception" in data_str.lower() or "something went wrong" in data_str.lower():
                    is_valid = False
                
                if is_valid and len(data_str) > 300:
                    print(f"\n🚨 SIKERES: match_{api_name}")
                    print(f"   URL: {url}")
                    print(f"   Méret: {len(data_str)} karakter")
                    print(f"   Preview: {data_str[:200]}")
                    
                    filename = f"MATCH_API_{api_name}_{test_match_id}.json"
                    with open(filename, 'w', encoding='utf-8') as f:
                        json.dump(data, f, indent=2, ensure_ascii=False)
                    
                    successes.append({
                        "api": f"match_{api_name}",
                        "url": url,
                        "file": filename,
                        "size": len(data_str)
                    })
                elif not is_valid:
                    print(f"   ⚠️ match_{api_name}: Exception/Error")
                
            except:
                print(f"   ⚠️ match_{api_name}: Nem JSON")
                
    except Exception as e:
        print(f"   ❌ match_{api_name}: {e}")

print("\n" + "="*70)
print("📊 VÉGEREDMÉNY - MŰKÖDŐ match_ API-K")
print("="*70)

if successes:
    print(f"\n🎉🎉🎉 TALÁLTUNK {len(successes)} MŰKÖDŐ API-T! 🎉🎉🎉\n")
    
    for s in successes:
        print(f"\n✅ {s['api']}")
        print(f"   URL: {s['url']}")
        print(f"   Méret: {s['size']} karakter")
        print(f"   Fájl: {s['file']}")
    
    with open('BREAKTHROUGH_MATCH_APIS.json', 'w', encoding='utf-8') as f:
        json.dump(successes, f, indent=2, ensure_ascii=False)
    
    print(f"\n💾 Részletek: BREAKTHROUGH_MATCH_APIS.json")
    print("\n🔥 KÖVETKEZŐ LÉPÉS:")
    print("   Elemezzük meg ezeket az API-kat részletesen!")
    print("   Keressük meg bennük az előre generált eredményeket!")
    
else:
    print("\n⚠️ Sajnos csak match_events és match_timeline működik...")
    print("   De ez is nagy előrelépés!")

print("\n✅ Teszt kész!")
