
# live_match_monitor.py
# ÉLŐ MÉRKŐZÉS MONITOROZÁSA - Real-time API változások figyelése
# Célja: Megtalálni, hogy HOL van az előre generált eredmény

import requests
import time
import json
from datetime import datetime

def get_current_season_and_round():
    """Aktuális szezon és forduló lekérése"""
    try:
        comp_api = "https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh"
        competitions = requests.get(comp_api, timeout=5).json()
        season_id = competitions["next_competitions"][0]["competition_id"]
        
        time_api = "https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0"
        timings = requests.get(time_api, timeout=5).json()
        
        # Keressünk LIVE meccset először
        for phase in timings.get("timings", []):
            if phase.get("phase_name") == "in_match":
                matches = phase.get("matches", [])
                if matches:
                    current_round = matches[0]["matchset_nr"]
                    match_id = matches[0]["id"]
                    return season_id, current_round, match_id, "in_match (LIVE)"
        
        # Ha nincs live, akkor betstop (közvetlenül meccs előtt)
        for phase in timings.get("timings", []):
            if phase.get("phase_name") == "betstop":
                matches = phase.get("matches", [])
                if matches:
                    current_round = matches[0]["matchset_nr"]
                    match_id = matches[0]["id"]
                    return season_id, current_round, match_id, "betstop (hamarosan kezdődik)"
        
        # Ha nincs betstop sem, akkor pre_match (következő meccs)
        if timings.get("timings"):
            phase = timings["timings"][0]
            matches = phase.get("matches", [])
            if matches:
                current_round = matches[0]["matchset_nr"]
                match_id = matches[0]["id"]
                return season_id, current_round, match_id, f"pre_match (következő forduló: {current_round})"
        
        return None, None, None, None
        
    except Exception as e:
        print(f"❌ Hiba a szezon/forduló lekérésénél: {e}")
        import traceback
        traceback.print_exc()
        return None, None, None, None

def fetch_full_feed(season_id, round_nr):
    """Full feed API lekérése"""
    try:
        url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{season_id}/{round_nr}"
        response = requests.get(url, timeout=10)
        return response.json()
    except Exception as e:
        print(f"❌ Full feed hiba: {e}")
        return None

def extract_match_data(full_feed, match_id):
    """Egy konkrét mérkőzés adatainak kinyerése"""
    try:
        doc = full_feed.get("doc", [{}])[0]
        data = doc.get("data", {})
        
        for key, value in data.items():
            if str(match_id) in str(key):
                return value
        
        # Ha nincs match_id, az első meccset nézzük
        if data:
            first_key = list(data.keys())[0]
            return data[first_key]
        
        return None
    except Exception as e:
        print(f"❌ Match data hiba: {e}")
        return None

def deep_inspect_fields(match_data, prefix=""):
    """Mélységi mező vizsgálat - MINDEN mezőt listáz"""
    fields = {}
    
    if isinstance(match_data, dict):
        for key, value in match_data.items():
            current_path = f"{prefix}.{key}" if prefix else key
            
            if isinstance(value, (dict, list)):
                fields.update(deep_inspect_fields(value, current_path))
            else:
                fields[current_path] = value
    
    elif isinstance(match_data, list):
        for i, item in enumerate(match_data):
            current_path = f"{prefix}[{i}]"
            if isinstance(item, (dict, list)):
                fields.update(deep_inspect_fields(item, current_path))
            else:
                fields[current_path] = item
    
    return fields

def compare_snapshots(snapshot1, snapshot2):
    """Két snapshot közötti különbségek"""
    changes = []
    
    all_keys = set(snapshot1.keys()) | set(snapshot2.keys())
    
    for key in all_keys:
        val1 = snapshot1.get(key)
        val2 = snapshot2.get(key)
        
        if val1 != val2:
            changes.append({
                "field": key,
                "old_value": val1,
                "new_value": val2,
                "timestamp": datetime.now().isoformat()
            })
    
    return changes

def search_for_secrets(match_data):
    """Rejtett/gyanús mezők keresése"""
    suspects = []
    
    # Gyanús kulcsszavak
    keywords = [
        "seed", "generated", "simulation", "prediction", "forecast",
        "outcome", "result_gen", "pre_calc", "random", "hash",
        "internal", "admin", "debug", "hidden", "secret"
    ]
    
    all_fields = deep_inspect_fields(match_data)
    
    for field, value in all_fields.items():
        for keyword in keywords:
            if keyword.lower() in field.lower():
                suspects.append({
                    "field": field,
                    "value": value,
                    "keyword_match": keyword
                })
    
    return suspects

def monitor_live_match(duration_minutes=5, check_interval_seconds=10):
    """ÉLŐ meccs monitorozása"""
    print("=" * 70)
    print("🔴 ÉLŐ MÉRKŐZÉS MONITOROZÁS")
    print("=" * 70)
    
    # Aktuális meccs keresése
    print("\n🔍 Aktuális mérkőzés keresése...")
    season_id, round_nr, match_id, phase = get_current_season_and_round()
    
    if not season_id:
        print("❌ Nem sikerült megtalálni az aktuális meccset!")
        return
    
    print(f"✅ Szezon: {season_id}, Forduló: {round_nr}, Fázis: {phase}")
    if match_id:
        print(f"✅ Mérkőzés ID: {match_id}")
    
    # Első snapshot
    print(f"\n📸 Első snapshot lekérése...")
    feed = fetch_full_feed(season_id, round_nr)
    if not feed:
        print("❌ Nem sikerült lekérni a feed-et!")
        return
    
    match_data = extract_match_data(feed, match_id)
    if not match_data:
        print("❌ Nem sikerült kinyerni a mérkőzés adatait!")
        return
    
    snapshot_initial = deep_inspect_fields(match_data)
    print(f"✅ {len(snapshot_initial)} mező rögzítve")
    
    # Rejtett mezők keresése
    print(f"\n🕵️ Rejtett/gyanús mezők keresése...")
    secrets = search_for_secrets(match_data)
    if secrets:
        print(f"⚠️  {len(secrets)} GYANÚS MEZŐ TALÁLVA:")
        for s in secrets[:10]:
            print(f"   • {s['field']} = {s['value']} (kulcsszó: {s['keyword_match']})")
    else:
        print("❌ Nincs gyanús kulcsszó a mezőkben")
    
    # Monitorozás
    total_checks = (duration_minutes * 60) // check_interval_seconds
    print(f"\n⏱️  Monitorozás {duration_minutes} percig ({total_checks} ellenőrzés, {check_interval_seconds}s-enként)...")
    
    all_changes = []
    previous_snapshot = snapshot_initial
    
    for i in range(total_checks):
        time.sleep(check_interval_seconds)
        
        print(f"\n📡 Ellenőrzés {i+1}/{total_checks} ({(i+1) * check_interval_seconds}s eltelt)...")
        
        # Új snapshot
        feed = fetch_full_feed(season_id, round_nr)
        if not feed:
            print("   ⚠️ Feed hiba, folytatás...")
            continue
        
        match_data = extract_match_data(feed, match_id)
        if not match_data:
            print("   ⚠️ Match data hiba, folytatás...")
            continue
        
        current_snapshot = deep_inspect_fields(match_data)
        
        # Változások detektálása
        changes = compare_snapshots(previous_snapshot, current_snapshot)
        
        if changes:
            print(f"   🔥 {len(changes)} VÁLTOZÁS ÉSZLELVE:")
            for change in changes[:5]:
                print(f"      • {change['field']}")
                print(f"        Régi: {change['old_value']}")
                print(f"        Új:   {change['new_value']}")
            
            all_changes.extend(changes)
            previous_snapshot = current_snapshot
        else:
            print("   ✓ Nincs változás")
    
    # Összefoglaló
    print("\n" + "=" * 70)
    print("📊 MONITOROZÁS ÖSSZEFOGLALÓ")
    print("=" * 70)
    print(f"✅ Ellenőrzések száma: {total_checks}")
    print(f"✅ Összes változás: {len(all_changes)}")
    
    if all_changes:
        print(f"\n🔥 VÁLTOZÓ MEZŐK TOP 10:")
        field_changes = {}
        for change in all_changes:
            field = change["field"]
            field_changes[field] = field_changes.get(field, 0) + 1
        
        sorted_fields = sorted(field_changes.items(), key=lambda x: x[1], reverse=True)
        for field, count in sorted_fields[:10]:
            print(f"   • {field}: {count}x változott")
    
    # Mentés
    output = {
        "season_id": season_id,
        "round_nr": round_nr,
        "match_id": match_id,
        "phase": phase,
        "monitoring_duration_minutes": duration_minutes,
        "total_checks": total_checks,
        "initial_fields_count": len(snapshot_initial),
        "total_changes": len(all_changes),
        "changes": all_changes,
        "suspicious_fields": secrets,
        "final_snapshot": current_snapshot
    }
    
    with open("live_match_monitoring.json", "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    print(f"\n💾 Részletes adatok mentve: live_match_monitoring.json")
    print("=" * 70)

if __name__ == "__main__":
    # 5 perc monitorozás, 10 másodpercenként ellenőrzés
    monitor_live_match(duration_minutes=5, check_interval_seconds=10)
