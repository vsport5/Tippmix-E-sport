# 🔗 MŰKÖDŐ API LINKEK - TELJES EGYESÍTETT LISTA

**Utolsó frissítés:** 2025-10-27  
**Összes API:** 319+ végpont  
**Kategóriák:** 20  
**Források:** Hálózati forgalom + Mélyített keresés + Automatikus scan

---

## ℹ️ FONTOS INFORMÁCIÓK

**Ez a dokumentum tartalmazza:**
- ✅ Minden működő API végpontot (konkrét példákkal)
- ✅ Automatikusan frissülő API-kat (competitions, timings)
- ✅ Mélyített keresés eredményeit
- ✅ Hálózati forgalomból kinyert API-kat
- ✅ Kategorizált és rendezett listát

**Felesleges fájlok (törölhetők):**
- `betting_apis.txt`, `deep_betting_apis.txt`
- `all_network_urls.txt`, `deep_all_network_urls.txt`
- `api_endpoints.txt`, `deep_api_endpoints.txt`
- `auto_api_endpoints.txt`, `all_found_urls.txt`, `working_apis.txt`
- `api_details.json`, `deep_api_details.json`

---

## 🎯 FOGADÁSI SZORZÓK (ODDS)

**API minta:** `match_odds2/{MATCH_ID}`

### Konkrét példák (8 aktív mérkőzés):

1. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_odds2/1390683004
2. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_odds2/1390683005
3. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_odds2/1390683006
4. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_odds2/1390683007
5. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_odds2/1390683008
6. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_odds2/1390683009
7. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_odds2/1390683010
8. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_odds2/1390683011

**Használat:** Cseréld ki a `{MATCH_ID}` részt az aktuális mérkőzés ID-jával

---

## 📊 CSAPAT STATISZTIKÁK (Utolsó 5 mérkőzés)

**API minta:** `stats_uniquetournament_team_lastx/14562/{TEAM_ID}/5`

### Konkrét példák (16 csapat):

1. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/276501/5
2. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/276502/5
3. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/276503/5
4. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/276504/5
5. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/276505/5
6. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/276506/5
7. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/276507/5
8. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/276508/5
9. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/276509/5
10. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/276510/5
11. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/276511/5
12. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/276512/5
13. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/276513/5
14. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/276514/5
15. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/276515/5
16. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/276516/5

**Használat:** Cseréld ki a `{TEAM_ID}` részt a csapat ID-jával

---

## ⚔️ HEAD-TO-HEAD (Egymás elleni meccsek)

**API minta:** `stats_uniquetournament_team_versusrecent/14562/{TEAM1}/{TEAM2}/5`

### Konkrét példák (13 csapat páros):

1. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/276501/276509/5
2. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/276502/276506/5
3. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/276503/276515/5
4. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/276504/276512/5
5. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/276505/276513/5
6. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/276507/276511/5
7. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/276508/276516/5
8. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/276514/276510/5
9. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/276501/276501/5
10. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/276502/276502/5
11. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/276503/276503/5
12. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/276505/276505/5
13. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/276516/276516/5

---

## 🔥 TELJES MÉRKŐZÉS FEED

### Első forduló:
https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{SEASON_ID}/1

### Utolsó forduló (30):
https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{SEASON_ID}/30

### Aktuális (példa - 25. forduló):
https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/3015230/25

---

## ⚡ ÉLŐ EREDMÉNYEK

### Első forduló:
https://vfdirectdata.live.vsports.cloud//14562/scigamingscigamingcdn/zh/Europe:Berlin/vf_livescore/{SEASON_ID}/league/1

### Utolsó forduló (30):
https://vfdirectdata.live.vsports.cloud//14562/scigamingscigamingcdn/zh/Europe:Berlin/vf_livescore/{SEASON_ID}/league/30

### Aktuális (példa - 25. forduló):
https://vfdirectdata.live.vsports.cloud//14562/scigamingscigamingcdn/zh/Europe:Berlin/vf_livescore/3015230/league/25

---

## 🏆 VERSENYEK / SZEZONOK (AUTOMATIKUS!)

https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh

**⚠️ EZ A LEGFONTOSABB API!**  
Ez mindig az aktuális szezont adja vissza a `next_competitions` mezőben!

---

## ⏰ IDŐZÍTÉSEK (AUTOMATIKUS!)

https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0

**⚠️ EZ IS KULCSFONTOSSÁGÚ!**  
Real-time adja az aktuális mérkőzéseket és fordulót!

---

## 🆔 MÉRKŐZÉS AZONOSÍTÓK

https://vf.live.vsports.cloud/vflmshop/mobile/eventIds.json?clientid=4997&lang=zh&seasonid={SEASON_ID}&stagetype=1&matchset={ROUND}

---

## 📈 TABELLA / ÁLLÁSOK

https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_tournament_livetablebyseasonandround/{SEASON_ID}/{ROUND}

---

## 🏅 SPORTRADAR API

https://s5.sir.sportradar.com/scigamingvirtuals/zh/1/season/{SEASON_ID}/h2h/{TEAM1}/{TEAM2}

---

## 💡 HASZNÁLATI ÚTMUTATÓ

### 1️⃣ Aktuális szezon és forduló automatikus lekérése:

```python
import requests

# Competitions API - Aktuális szezon
comp = requests.get("https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh").json()
season_id = comp["next_competitions"][0]["competition_id"]

# Timings API - Aktuális forduló
timings = requests.get("https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0").json()
round_nr = timings["timings"][0]["matches"][0]["matchset_nr"]

print(f"Szezon: {season_id}, Forduló: {round_nr}")
```

### 2️⃣ Dinamikus URL építés:

```python
# Teljes feed
full_feed = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{season_id}/{round_nr}"

# Élő eredmény
livescore = f"https://vfdirectdata.live.vsports.cloud//14562/scigamingscigamingcdn/zh/Europe:Berlin/vf_livescore/{season_id}/league/{round_nr}"
```

---

## 📊 ÖSSZEFOGLALÓ

**Ezzel az egy dokumentummal megvan MINDEN, amit használnod kell!**

✅ 319+ API végpont  
✅ Automatikus frissítés logika  
✅ Konkrét példák  
✅ Használati útmutatók  
✅ Python kód példák  

**További dokumentációk:**
- `AUTOMATIKUS_AKTUALIS_API.md` - Részletes automatikus frissítés
- `BETTING_API_SUMMARY.md` - Fogadási stratégiák
- `SZEZON_ES_FORDULO_API.md` - Teljes szezon struktúra

---

**Készítve:** 2025-10-27  
**Forrás:** Hálózati forgalom + Mélyített scan + Auto-detect  
**Státusz:** ✅ Teljes és egyesített