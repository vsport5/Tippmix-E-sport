# Virtual Sports API Scanner & Analyzer

## 📋 Projekt áttekintés

**Cél:** Virtuális sportfogadási rendszerek (Virtual Football League - VFL) API-jainak teljes feltérképezése, elemzése és dokumentálása.

**Állapot:** Alapvető kutatás és dokumentáció kész, fejlesztésre kész állapotban.

**Utolsó frissítés:** 2025-10-27

---

## 🎯 Projekt célkitűzései

1. **API feltérképezés:** Összes elérhető API végpont automatikus felderítése
2. **Rejtett adatok keresése:** Settlement API-k, előre generált eredmények, simulation seeds azonosítása
3. **Kategorizálás:** API-k csoportosítása funkciók szerint (odds, stats, h2h, livescore, stb.)
4. **Dokumentáció:** Részletes használati útmutatók és példakódok készítése
5. **Automatizálás:** Auto-updating API-k azonosítása (competitions, timings)

---

## 🏗️ Projekt architektúra

### Fő komponensek

#### 1. Scanner szkriptek
- `main.py` - Alapvető hálózati forgalom figyelés (60s)
- `deep_api_scanner.py` - Mélyített keresés interakciókkal (10 perc)
- `advanced_api_hunter.py` - Speciális keresés: hidden endpoints (3 perc)

#### 2. Elemző szkriptek
- `deep_analyzer.py` - API-k mélyreható elemzése, rejtett mezők keresése
- `analyze_past_matches.py` - Múltbeli mérkőzések elemzése
- `live_match_monitor.py` - Élő mérkőzések real-time monitorozása
- `test_settlements.py` - Settlement API végpontok tesztelése

#### 3. Dokumentáció generátorok
- `categorize_apis.py` - API-k kategorizálása
- `generate_summary.py` - HTML dashboard készítése
- `find_hidden_endpoints.py` - Rejtett végpontok keresése (placeholder)

#### 4. Web interfész
- `server.py` - HTTP szerver (port 5000) dokumentációk megjelenítésére
- `index.html` - Visual dashboard

---

## 📚 Kulcsfontosságú dokumentumok

### API Dokumentációk
1. **`MUKODO_API_LINKEK.md`** - 319+ működő API végpont teljes listája konkrét példákkal
2. **`MELYITETT_API_LINKEK.md`** - Kategorizált API linkek (1674 API, 20 kategória)
3. **`BETTING_API_SUMMARY.md`** - Fogadási stratégiák és használati útmutató
4. **`AUTOMATIKUS_AKTUALIS_API.md`** - Auto-updating API-k dokumentációja
5. **`SZEZON_ES_FORDULO_API.md`** - Szezon/forduló struktúra részletes leírása

### Technikai dokumentáció
- `agent_state_log.json` - Strukturált projekt állapot napló (gépi olvasásra)
- `replit.md` - Ez a fájl (ember és agent számára egyaránt)

---

## 🔑 Kritikus API végpontok

### Automatikusan frissülő API-k (mindig aktuális adatok)
```python
# 1. Aktuális szezon lekérése
competitions_url = "https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh"
# Válasz: next_competitions[0].competition_id = aktuális szezon ID

# 2. Aktuális forduló lekérése
timings_url = "https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0"
# Válasz: timings[0].matches[0].matchset_nr = aktuális forduló
```

### API kategóriák
- **Odds (84 API):** Fogadási szorzók - `match_odds2/{MATCH_ID}`
- **Team Stats (706 API):** Csapat statisztikák - `stats_uniquetournament_team_lastx/14562/{TEAM_ID}/5`
- **H2H:** Egymás elleni mérkőzések - `stats_uniquetournament_team_versusrecent/14562/{TEAM1}/{TEAM2}/5`
- **Full Feed:** Teljes mérkőzés adat - `vfl_event_fullfeed/{SEASON_ID}/{ROUND}`
- **Livescore (332 API):** Élő eredmények - `vf_livescore/{SEASON_ID}/league/{ROUND}`

---

## 🛠️ Technológiai stack

### Futtatási környezet
- **Platform:** Replit
- **Python verzió:** >=3.11
- **Operációs rendszer:** NixOS (Replit environment)

### Függőségek (pyproject.toml)
```toml
[project]
dependencies = [
    "beautifulsoup4>=4.14.2",
    "requests>=2.32.5",
    "selenium>=4.38.0",
]
```

### Használt technológiák
- **Selenium + Chrome CDP:** Hálózati forgalom real-time figyelése
- **requests:** API lekérdezések
- **beautifulsoup4:** HTML parsing
- **JSON:** Adatok mentése és elemzése

---

## 📊 Projekt eredmények

### Statisztikák
- **Összesen talált API:** 1674
- **Kategóriák száma:** 27
- **Mélyített scan idő:** 10 perc
- **Működő API végpontok:** 319+

### Generált adatfájlok
**JSON dumps:**
- `competitions_full_dump.json`, `timings_full_dump.json`, `full_feed_dump.json`
- `deep_api_details.json`, `advanced_api_details.json`
- `past_matches_analysis.json`, `live_match_monitoring.json`

**Rejtett adatok (hidden_*.json):**
- admin, config, debug, fixture_outcomes, generated_data, internal, metadata
- outcomes, pre_generated, predictions, probabilities, results, seeds
- settlements, simulation_results

---

## 🚀 Workflow konfiguráció

### Jelenlegi állapot
**Nincs workflow konfigurálva** - Read-only analysis mód

### Javasolt workflow (fejlesztés indításakor)
```python
# Server indítása
Command: python server.py
Port: 5000
Output: webview
Purpose: API dokumentációk megjelenítése böngészőben
```

---

## 🎓 User preferences

### Nyelv
- **Kommunikáció:** Magyar
- **Kód kommentek:** Magyar vagy angol (kevés komment preferált)
- **Dokumentáció:** Magyar

### Fejlesztési preferenciák
- **Kód stílus:** Clean, jól strukturált, érthető
- **Dokumentáció:** Részletes Markdown fájlok példákkal
- **Adatok:** Valódi API válaszok, NO mock data
- **Verziókezelés:** Git commitok (automatikus Replit által)

### Projekt specifikus preferenciák
- **API keresés:** Mélyreható, minden lehetséges végpont feltárása
- **Rejtett adatok:** Prioritás a settlement, seed, generated mezők keresésében
- **Dokumentáció:** Markdown + HTML, vizuális megjelenítéssel
- **Automatizálás:** Auto-updating API-k használata

---

## 📝 Recent changes

### 2025-10-27 (Continuation Agent)
- ✅ Teljes projekt beolvasva és értelmezve
- ✅ Összes fő komponens azonosítva
- ✅ Dokumentációk áttekintve
- ✅ `agent_state_log.json` létrehozva (strukturált projekt állapot)
- ✅ `replit.md` létrehozva (projekt memória fájl)
- 📋 Várakozás "FEJLESZTHETSZ" jelzésre

---

## ⚠️ Known issues

### LSP hibák
- **Fájl:** `main.py`
- **Hibák száma:** 4
- **Súlyosság:** Info (nem kritikus)
- **Státusz:** Átnézésre vár fejlesztés indításakor

---

## 🔮 Következő lépések (fejlesztés indításakor)

1. **Workflow beállítás**
   - Server.py indítása port 5000-en
   - Webview output beállítása
   - Console log ellenőrzés

2. **LSP hibák javítása**
   - main.py átnézése
   - Szükség esetén javítások

3. **További fejlesztések**
   - Hidden endpoint keresés folytatása
   - Settlement API mélyebb elemzése
   - Dashboard továbbfejlesztése
   - Real-time monitoring továbbfejlesztése

4. **Tesztelés**
   - Összes scanner szkript tesztelése
   - API végpontok validálása
   - Dokumentáció frissítése új eredményekkel

---

## 💡 Megjegyzések későbbi agenteknek

### Projekt érettség
- **Állapot:** Jól fejlett, alapos API kutatás elvégezve
- **Kód minőség:** Jó, tiszta, érthető szkriptek
- **Dokumentáció minőség:** Kiváló, részletes példákkal
- **Folytatásra kész:** ✅ Igen

### Ajánlott megközelítés
1. Olvasd be ezt a fájlt (`replit.md`) és az `agent_state_log.json`-t
2. Nézd át a kulcsfontosságú dokumentációkat (MUKODO_API_LINKEK.md, stb.)
3. Futtasd a server.py-t és nézd meg a dashboardot
4. Folytasd a hidden endpoint kutatást vagy fejlessz új funkciókat

### Figyelem
- **NE törölj** meglévő JSON dump fájlokat (értékes kutatási adatok!)
- **NE változtass** az alap API scanner logikán breaking change nélkül
- **MINDIG** dokumentáld az új API találatokat a megfelelő MD fájlokban
- **TESZTELJ** minden változtatást az élő API-kkal

---

**Projekt tulajdonos:** User (magyar nyelvű)  
**Agent típus:** Continuation-aware, Hungarian language support  
**Környezet:** Replit, Python 3.11+, No virtual environment
