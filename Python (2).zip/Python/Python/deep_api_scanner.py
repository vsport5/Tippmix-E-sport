# deep_api_scanner.py
# MÉLYÍTETT API VÉGPONT KERESÉS - Interaktív oldalfigyelés
# Célja: MINDEN lehetséges API végpont megtalálása hosszabb futással és interakciókkal

import time, re, json, random
from urllib.parse import urljoin, urlparse, parse_qs

SAVE_FILE_DEEP_API = "deep_api_endpoints.txt"
SAVE_FILE_DEEP_BETTING = "deep_betting_apis.txt"
SAVE_FILE_DEEP_ALL = "deep_all_network_urls.txt"
SAVE_FILE_DEEP_DETAILED = "deep_api_details.json"

RUN_TIME = 600  # 10 PERC futási idő (600 másodperc)
TARGET_PAGE = "https://vfscigaming.aitcloud.de/vflmshop/retail/index?channel=7&clientid=4997&lang=zh&screen=betradar_vflm_one_screen&style=scigamingcdn"

def save_urls(urls, fname):
    with open(fname, "w", encoding="utf-8") as f:
        for u in sorted(urls):
            f.write(u + "\n")
    print(f"✅ {len(urls)} URL mentve: {fname}")

def save_json(data, fname):
    with open(fname, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print(f"✅ Részletes adatok mentve: {fname}")

def is_betting_api(url, headers=None):
    """Fogadáshoz kapcsolódó API-k azonosítása - BŐVÍTETT"""
    betting_keywords = [
        r"odds",
        r"bet",
        r"wager",
        r"stake",
        r"match",
        r"fixture",
        r"event",
        r"game",
        r"result",
        r"score",
        r"market",
        r"settlement",
        r"h2h",
        r"head.*to.*head",
        r"statistics",
        r"stats",
        r"probability",
        r"team",
        r"league",
        r"season",
        r"schedule",
        r"live",
        r"feed",
        r"virtual",
        r"vfl",
        r"sportradar",
        r"betradar",
        r"competition",
        r"tournament",
        r"round",
        r"matchset",
        r"phase",
        r"timing",
        r"livescore",
        r"fullfeed",
        r"versus",
        r"lastx",
        r"gismo",
        r"widget",
        r"vsports",
        r"eventIds",
        r"jersey",
        r"table",
        r"standing"
    ]
    
    for keyword in betting_keywords:
        if re.search(keyword, url, re.I):
            return True
    
    if headers:
        accept = headers.get("accept", "").lower()
        content_type = headers.get("content-type", "").lower()
        if "json" in accept or "xml" in accept or "json" in content_type or "xml" in content_type:
            return True
    
    return False

def looks_like_static(url):
    """Statikus fájlok kiszűrése"""
    static_extensions = [
        r"\.js(\?|$)",
        r"\.css(\?|$)",
        r"\.png(\?|$)",
        r"\.jpg(\?|$)",
        r"\.jpeg(\?|$)",
        r"\.gif(\?|$)",
        r"\.svg(\?|$)",
        r"\.woff2?(\?|$)",
        r"\.ttf(\?|$)",
        r"\.eot(\?|$)",
        r"\.mp4(\?|$)",
        r"\.webm(\?|$)",
        r"\.ico(\?|$)",
        r"\.webp(\?|$)",
        r"\.avif(\?|$)"
    ]
    
    for ext in static_extensions:
        if re.search(ext, url, re.I):
            return True
    return False

def extract_api_patterns_from_source(html_source):
    """API minták kinyerése a forrásból - MÉLYEBB ELEMZÉS"""
    patterns = set()
    
    # API endpoint regex minták
    api_regexes = [
        # URL-ek HTTP/HTTPS-szel
        r'https?://[^\s\'\"<>]+',
        # Relatív API útvonalak
        r'/api/[^\s\'\"<>]+',
        r'/vfl/[^\s\'\"<>]+',
        r'/mobile/[^\s\'\"<>]+',
        r'/feeds/[^\s\'\"<>]+',
        # Speciális minták
        r'gismo/[^\s\'\"<>]+',
        r'vswidgets/[^\s\'\"<>]+',
        r'scigaming[^\s\'\"<>]+',
    ]
    
    for regex in api_regexes:
        matches = re.findall(regex, html_source, re.I)
        for match in matches:
            cleaned = match.rstrip('",;)\'"')
            if not looks_like_static(cleaned):
                patterns.add(cleaned)
    
    # JSON objektumokból URL-ek
    json_regex = r'"(https?://[^"]+)"'
    json_urls = re.findall(json_regex, html_source)
    for url in json_urls:
        if not looks_like_static(url):
            patterns.add(url)
    
    return patterns

def simulate_interactions(driver):
    """Oldal interakciók szimulálása - GÖRGETÉS, VÁRAKOZÁS, KLIKKELÉS"""
    try:
        print("🖱️  Interakciók szimulálása...")
        
        # Görgetés lefelé lépésekben
        scroll_steps = 10
        viewport_height = driver.execute_script("return window.innerHeight")
        
        for i in range(scroll_steps):
            scroll_position = (i + 1) * (viewport_height // 2)
            driver.execute_script(f"window.scrollTo(0, {scroll_position});")
            time.sleep(0.5)
            print(f"   Görgetés: {i+1}/{scroll_steps}")
        
        # Görgetés vissza felfelé
        driver.execute_script("window.scrollTo(0, 0);")
        time.sleep(1)
        
        # Próbálunk meg kattintani elemekre (ha vannak)
        try:
            clickable_elements = driver.execute_script("""
                return Array.from(document.querySelectorAll('button, a, [role="button"], [onclick]'))
                    .slice(0, 5)
                    .map(el => el.tagName);
            """)
            print(f"   Kattintható elemek találva: {len(clickable_elements)}")
        except:
            pass
        
        print("✅ Interakciók befejezve")
        
    except Exception as e:
        print(f"⚠️  Interakció hiba (nem kritikus): {e}")

def deep_scan_with_network_monitoring(target, run_time=RUN_TIME):
    """Selenium + CDP hálózati forgalom figyelés - BŐVÍTETT VERZIÓ"""
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.common.by import By
    
    print("🔧 Chrome böngésző indítása MÉLY hálózati figyeléssel...")
    options = Options()
    options.add_argument("--headless")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    options.add_argument("--window-size=1920,1080")
    
    # Engedélyezzük a logging-ot
    options.set_capability("goog:loggingPrefs", {"performance": "ALL"})
    
    network_data = []
    
    try:
        driver = webdriver.Chrome(options=options)
        
        # CDP parancsok engedélyezése
        driver.execute_cdp_cmd("Network.enable", {})
        driver.execute_cdp_cmd("Page.enable", {})
        
        print(f"🌐 Oldal betöltése: {target}")
        driver.get(target)
        
        print(f"⏳ MÉLY figyelés {run_time} másodpercig ({run_time//60} perc)...")
        print("   (Várjuk, hogy MINDEN API hívás, mérkőzés, odds betöltődjön)")
        
        # Első 30 másodperc: Várakozás az oldal inicializálására
        print("\n📍 1. fázis: Inicializálás (30s)...")
        time.sleep(30)
        
        # Interakciók szimulálása
        print("\n📍 2. fázis: Interakciók szimulálása...")
        simulate_interactions(driver)
        
        # Maradék idő: További várakozás + periodikus ellenőrzések
        remaining_time = run_time - 30 - 10  # 30s init + ~10s interactions
        check_interval = 30  # 30 másodpercenként nézünk
        checks = remaining_time // check_interval
        
        print(f"\n📍 3. fázis: Folyamatos figyelés ({checks} ellenőrzés, {check_interval}s-enként)...")
        for i in range(checks):
            time.sleep(check_interval)
            
            # Periodikus görgetés
            if i % 3 == 0:
                driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(1)
                driver.execute_script("window.scrollTo(0, 0);")
            
            print(f"   Ellenőrzés {i+1}/{checks} - {(i+1) * check_interval}s eltelt")
        
        print("\n📡 Hálózati logok gyűjtése és elemzése...")
        
        # Performance logok elemzése
        logs = driver.get_log("performance")
        
        print(f"   Összesen {len(logs)} performance log bejegyzés")
        
        for entry in logs:
            try:
                log_entry = json.loads(entry["message"])
                message = log_entry.get("message", {})
                method = message.get("method", "")
                
                # Kérések figyelése
                if method == "Network.requestWillBeSent":
                    params = message.get("params", {})
                    request = params.get("request", {})
                    url = request.get("url", "")
                    headers = request.get("headers", {})
                    
                    if url and not looks_like_static(url):
                        network_data.append({
                            "url": url,
                            "method": request.get("method", "GET"),
                            "headers": headers,
                            "timestamp": params.get("timestamp", 0),
                            "type": "request"
                        })
                
                # Válaszok figyelése
                elif method == "Network.responseReceived":
                    params = message.get("params", {})
                    response = params.get("response", {})
                    url = response.get("url", "")
                    
                    if url and not looks_like_static(url):
                        mime_type = response.get("mimeType", "")
                        if "json" in mime_type or "xml" in mime_type or "text" in mime_type:
                            network_data.append({
                                "url": url,
                                "type": "response",
                                "mimeType": mime_type,
                                "status": response.get("status", 0)
                            })
                
                # WebSocket események
                elif method == "Network.webSocketCreated":
                    params = message.get("params", {})
                    ws_url = params.get("url", "")
                    if ws_url:
                        network_data.append({
                            "url": ws_url,
                            "type": "websocket",
                            "method": "WEBSOCKET"
                        })
                        
            except Exception as e:
                continue
        
        # Oldal forráskódjából is keresünk - MÉLYEBB ELEMZÉS
        page_source = driver.page_source
        print(f"📄 Oldal forrás hossza: {len(page_source)} karakter")
        
        print("🔍 API minták keresése a forráskódban...")
        source_patterns = extract_api_patterns_from_source(page_source)
        
        # JavaScript változók értékeit is próbáljuk kinyerni
        try:
            js_urls = driver.execute_script("""
                var urls = [];
                // window objektumból keresünk URL-eket
                for (var key in window) {
                    try {
                        var value = window[key];
                        if (typeof value === 'string' && (value.startsWith('http://') || value.startsWith('https://'))) {
                            urls.push(value);
                        }
                    } catch(e) {}
                }
                return urls;
            """)
            print(f"   JavaScript változókból: {len(js_urls)} URL")
            source_patterns.update(js_urls)
        except:
            pass
        
        driver.quit()
        
        print(f"\n🔍 Gyűjtött adatok:")
        print(f"   Hálózati logok: {len(network_data)} bejegyzés")
        print(f"   Forrásból minták: {len(source_patterns)} URL")
        
        return network_data, source_patterns
        
    except Exception as e:
        print(f"❌ Hiba: {e}")
        try:
            driver.quit()
        except:
            pass
        return [], set()

def analyze_and_categorize(network_data, source_urls):
    """API-k elemzése és kategorizálása - BŐVÍTETT"""
    
    all_urls = set()
    betting_apis = set()
    api_details = []
    
    # Hálózati adatok feldolgozása
    for entry in network_data:
        url = entry.get("url", "")
        if not url:
            continue
        
        all_urls.add(url)
        
        # Betting API?
        headers = entry.get("headers", {})
        if is_betting_api(url, headers):
            betting_apis.add(url)
            
            # Részletes info
            api_details.append({
                "url": url,
                "type": "betting",
                "method": entry.get("method", "GET"),
                "detected_from": "network_log",
                "keywords": extract_keywords(url),
                "mime_type": entry.get("mimeType", ""),
                "entry_type": entry.get("type", "unknown")
            })
    
    # Forrás URL-ek feldolgozása
    for url in source_urls:
        all_urls.add(url)
        
        if is_betting_api(url):
            betting_apis.add(url)
            
            if not any(d["url"] == url for d in api_details):
                api_details.append({
                    "url": url,
                    "type": "betting",
                    "detected_from": "page_source",
                    "keywords": extract_keywords(url)
                })
    
    return all_urls, betting_apis, api_details

def extract_keywords(url):
    """Kulcsszavak kinyerése az URL-ből - BŐVÍTETT"""
    keywords = []
    
    betting_terms = [
        "odds", "bet", "match", "event", "result", "score", 
        "market", "settlement", "h2h", "stats", "team", 
        "league", "season", "live", "feed", "virtual",
        "competition", "tournament", "round", "phase",
        "timing", "livescore", "fullfeed", "gismo",
        "widget", "vsports", "eventIds"
    ]
    
    for term in betting_terms:
        if re.search(term, url, re.I):
            keywords.append(term)
    
    return keywords

def print_summary(all_urls, betting_apis, api_details):
    """Összefoglaló kiírása - BŐVÍTETT"""
    print("\n" + "=" * 70)
    print("📊 MÉLYÍTETT KERESÉS ÖSSZEFOGLALÓJA")
    print("=" * 70)
    print(f"✅ Összes talált URL: {len(all_urls)}")
    print(f"🎯 Fogadáshoz kapcsolódó API-k: {len(betting_apis)}")
    
    # Hálózati vs Forrás szerinti bontás
    from_network = sum(1 for d in api_details if d.get("detected_from") == "network_log")
    from_source = sum(1 for d in api_details if d.get("detected_from") == "page_source")
    
    print(f"\n📡 Forrás szerinti bontás:")
    print(f"   • Hálózati forgalomból: {from_network}")
    print(f"   • Oldal forráskódból: {from_source}")
    
    if betting_apis:
        print("\n🎲 FOGADÁSI API VÉGPONTOK (első 20):")
        for i, url in enumerate(sorted(betting_apis)[:20], 1):
            print(f"  {i}. {url}")
    
    # Kategorizálás típus szerint
    categories = {}
    for detail in api_details:
        keywords = detail.get("keywords", [])
        for kw in keywords:
            if kw not in categories:
                categories[kw] = []
            categories[kw].append(detail["url"])
    
    if categories:
        print("\n📂 KATEGÓRIÁK (top 15):")
        sorted_cats = sorted(categories.items(), key=lambda x: len(x[1]), reverse=True)[:15]
        for category, urls in sorted_cats:
            print(f"  • {category.upper()}: {len(urls)} API")

def main():
    print("=" * 70)
    print("🔍 MÉLYÍTETT API VÉGPONT KERESÉS")
    print("=" * 70)
    print("Fogadási rendszerhez szükséges API-k feltérképezése")
    print(f"Futási idő: {RUN_TIME//60} perc ({RUN_TIME} másodperc)")
    print("Interakciók: Görgetés, várakozás, periodikus ellenőrzések\n")
    
    start_time = time.time()
    
    # Hálózati forgalom figyelése
    network_data, source_urls = deep_scan_with_network_monitoring(TARGET_PAGE, RUN_TIME)
    
    if not network_data and not source_urls:
        print("⚠️ Nem sikerült adatot gyűjteni")
        return
    
    # Elemzés és kategorizálás
    print("\n📊 Adatok elemzése...")
    all_urls, betting_apis, api_details = analyze_and_categorize(network_data, source_urls)
    
    # Mentés
    print("\n💾 Fájlok mentése...")
    save_urls(all_urls, SAVE_FILE_DEEP_ALL)
    save_urls(betting_apis, SAVE_FILE_DEEP_BETTING)
    
    # API-k részletesen
    api_urls = set(d["url"] for d in api_details)
    save_urls(api_urls, SAVE_FILE_DEEP_API)
    save_json(api_details, SAVE_FILE_DEEP_DETAILED)
    
    # Összefoglaló
    print_summary(all_urls, betting_apis, api_details)
    
    elapsed_time = time.time() - start_time
    
    print("\n" + "=" * 70)
    print("📁 MENTETT FÁJLOK:")
    print(f"  • {SAVE_FILE_DEEP_BETTING} - Fogadási API-k ({len(betting_apis)} db)")
    print(f"  • {SAVE_FILE_DEEP_API} - Összes API ({len(api_urls)} db)")
    print(f"  • {SAVE_FILE_DEEP_ALL} - Minden URL ({len(all_urls)} db)")
    print(f"  • {SAVE_FILE_DEEP_DETAILED} - Részletes elemzés (JSON)")
    print("=" * 70)
    print(f"⏱️  Futási idő: {elapsed_time:.1f} másodperc ({elapsed_time/60:.1f} perc)")
    print("✅ MÉLYÍTETT KERESÉS BEFEJEZVE!")

if __name__ == "__main__":
    main()
