import requests
import json
import time

print("🎯 ÚJ STRATÉGIA: LEZÁRT MÉRKŐZÉSEK TESZTELÉSE!")
print("="*70)
print("Ha egy meccs VÉG VAN, akkor BIZTOSAN van settlement/result!\n")

# 1. AKTUÁLIS SZEZON/FORDULÓ
comp_data = requests.get("https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh").json()
season_id = comp_data["next_competitions"][0]["competition_id"]

time_data = requests.get("https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0").json()
current_round = time_data["timings"][0]["matches"][0]["matchset_nr"]

print(f"Aktuális: Season {season_id}, Round {current_round}\n")

# 2. LEZÁRT FORDULÓK - Visszamegyünk 5 fordulót
print("📍 LEZÁRT FORDULÓK lekérése...")
past_rounds = list(range(max(1, current_round - 5), current_round))
print(f"Tesztelendő fordulók: {past_rounds}\n")

# 3. MINDEN LEZÁRT FORDULÓBÓL KIVESSZÜK A MATCH ID-KAT
finished_matches = []

for round_nr in past_rounds:
    feed_url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{season_id}/{round_nr}"
    
    try:
        feed = requests.get(feed_url, timeout=5).json()
        matches_data = feed["doc"][0]["data"]["1"]["realcategories"]["1111"]["tournaments"]["56369"]["matches"]
        
        for match_id, match in matches_data.items():
            result = match.get("result", {})
            if result.get("home") is not None and result.get("away") is not None:
                finished_matches.append({
                    "match_id": match_id,
                    "round": round_nr,
                    "home": match["teams"]["home"]["name"],
                    "away": match["teams"]["away"]["name"],
                    "score": f"{result['home']}-{result['away']}"
                })
        
        print(f"   Forduló {round_nr}: {len(matches_data)} meccs, {sum(1 for m in matches_data.values() if m.get('result', {}).get('home') is not None)} lezárva")
    except Exception as e:
        print(f"   ⚠️ Forduló {round_nr} hiba: {e}")

print(f"\n✅ Összesen {len(finished_matches)} LEZÁRT mérkőzés\n")

# 4. TESZTELJÜK A KRITIKUS API-KAT LEZÁRT MÉRKŐZÉSEKKEL!
print("="*70)
print("🔥 TESZTELÉS: PREDICTIONS, SETTLEMENTS, RESULTS A LEZÁRT MECCSEKKEL")
print("="*70)

critical_apis = [
    "predictions",
    "pregenerated", 
    "settlements",
    "results",
    "outcomes",
    "simulation",
    "generated"
]

base = "https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/"

successes = []

# Első 10 lezárt meccset teszteljük
for match_info in finished_matches[:10]:
    match_id = match_info["match_id"]
    round_nr = match_info["round"]
    
    print(f"\n🎯 Match {match_id} (Forduló {round_nr}): {match_info['home']} {match_info['score']} {match_info['away']}")
    
    for api in critical_apis:
        # Próbáljuk match_id-val
        url = f"{base}{api}/{match_id}"
        
        try:
            resp = requests.get(url, timeout=2)
            if resp.status_code == 200:
                try:
                    data = resp.json()
                    data_str = str(data)
                    
                    # NEM exception?
                    if "exception" not in data_str.lower() and "something went wrong" not in data_str.lower():
                        if len(data_str) > 300:
                            print(f"   🚨🚨🚨 SIKERES: {api}")
                            print(f"      URL: {url}")
                            print(f"      Méret: {len(data_str)} karakter")
                            print(f"      Preview: {data_str[:150]}")
                            
                            filename = f"FINISHED_MATCH_{api}_{match_id}.json"
                            with open(filename, 'w', encoding='utf-8') as f:
                                json.dump(data, f, indent=2, ensure_ascii=False)
                            
                            successes.append({
                                "api": api,
                                "match_id": match_id,
                                "url": url,
                                "file": filename,
                                "match_info": match_info
                            })
                except:
                    pass
        except:
            pass
        
        # Próbáljuk season/round-dal is
        url2 = f"{base}{api}/{season_id}/{round_nr}"
        try:
            resp = requests.get(url2, timeout=2)
            if resp.status_code == 200:
                try:
                    data = resp.json()
                    if "exception" not in str(data).lower() and len(str(data)) > 300:
                        print(f"   ✅ {api} (season/round): {len(str(data))} char")
                        
                        filename = f"ROUND_{api}_{season_id}_{round_nr}.json"
                        with open(filename, 'w', encoding='utf-8') as f:
                            json.dump(data, f, indent=2, ensure_ascii=False)
                        
                        successes.append({
                            "api": api,
                            "pattern": "season/round",
                            "url": url2,
                            "file": filename
                        })
                except:
                    pass
        except:
            pass

print("\n\n" + "="*70)
print("📊 VÉGEREDMÉNY")
print("="*70)

if successes:
    print(f"\n🎉🎉🎉 SIKERES API HÍVÁSOK: {len(successes)} 🎉🎉🎉\n")
    
    for s in successes:
        print(f"\n🔥 API: {s['api']}")
        print(f"   URL: {s['url']}")
        print(f"   Fájl: {s['file']}")
        if 'match_info' in s:
            print(f"   Meccs: {s['match_info']['home']} {s['match_info']['score']} {s['match_info']['away']}")
    
    with open('BREAKTHROUGH_RESULTS.json', 'w', encoding='utf-8') as f:
        json.dump(successes, f, indent=2, ensure_ascii=False)
    
    print(f"\n💾 ÁTTÖRÉS! Részletek: BREAKTHROUGH_RESULTS.json")
    
else:
    print("\n⚠️ Még mindig nem sikerült...")
    print("\n💡 KÖVETKEZŐ PRÓBÁLKOZÁS:")
    print("   1. Teszteljük RÉGEBBI szezonokat")
    print("   2. Próbáljuk UNIX timestamp-eket paraméterként")
    print("   3. Nézzük meg a JavaScript kódot az oldalon")
    print("   4. Figyeljük a böngésző hálózati forgalmát élő meccsnél")

print("\n✅ Teszt befejezve!")
