
# advanced_api_hunter.py
# HALADÓ API VADÁSZ - Rejtett és előre generált adatok keresése
# Célja: Settlement API-k, pre-generated results, simulation data

import time
import re
import json
import requests
from urllib.parse import urljoin, urlparse, parse_qs

SAVE_FILE_ADVANCED = "advanced_apis.txt"
SAVE_FILE_SETTLEMENTS = "settlement_apis.txt"
SAVE_FILE_RESULTS = "result_apis.txt"
SAVE_FILE_JSON = "advanced_api_details.json"

RUN_TIME = 180  # 3 perc speciális keresés
TARGET_PAGE = "https://vfscigaming.aitcloud.de/vflmshop/retail/index?channel=7&clientid=4997&lang=zh&screen=betradar_vflm_one_screen&style=scigamingcdn"

def is_interesting_api(url, headers=None):
    """Érdekes/rejtett API-k azonosítása"""
    interesting_keywords = [
        r"settlement",      # Elszámolási adatok
        r"result",          # Eredmények
        r"outcome",         # Kimenetelek
        r"resolved",        # Lezárt események
        r"simulation",      # Szimuláció
        r"generated",       # Generált adatok
        r"pregenerated",    # Előre generált
        r"fixture",         # Mérkőzés adatok
        r"seed",            # Seed (randomizálás)
        r"prediction",      # Előrejelzés
        r"forecast",        # Előrejelzés
        r"probability",     # Valószínűség
        r"calculator",      # Kalkulátor
        r"engine",          # Motor
        r"generator",       # Generátor
        r"admin",           # Admin
        r"internal",        # Belső
        r"private",         # Privát
        r"debug",           # Debug
        r"test",            # Teszt
        r"dev",             # Fejlesztői
        r"config",          # Konfiguráció
        r"metadata",        # Metaadatok
        r"manifest",        # Manifest
        r"schedule",        # Ütemterv
        r"timeline",        # Idővonal
        r"history",         # Történet
        r"archive",         # Archívum
        r"backup",          # Backup
        r"export",          # Export
        r"dump",            # Dump
        r"raw",             # Nyers adat
        r"full",            # Teljes adat
        r"complete",        # Teljes
        r"all",             # Összes
    ]
    
    for keyword in interesting_keywords:
        if re.search(keyword, url, re.I):
            return True
    
    # Header ellenőrzés
    if headers:
        content_type = headers.get("content-type", "").lower()
        if "json" in content_type or "xml" in content_type:
            return True
    
    return False

def deep_network_scan():
    """Mély hálózati scan speciális API-kért"""
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    
    print("🔧 Speciális scanner indítása...")
    options = Options()
    options.add_argument("--headless")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.set_capability("goog:loggingPrefs", {"performance": "ALL"})
    
    found_apis = []
    
    try:
        driver = webdriver.Chrome(options=options)
        driver.execute_cdp_cmd("Network.enable", {})
        
        print(f"🌐 Oldal betöltése...")
        driver.get(TARGET_PAGE)
        
        print(f"⏳ {RUN_TIME}s figyelés...")
        time.sleep(RUN_TIME)
        
        print("📡 Logok elemzése...")
        logs = driver.get_log("performance")
        
        for entry in logs:
            try:
                log_entry = json.loads(entry["message"])
                message = log_entry.get("message", {})
                method = message.get("method", "")
                
                if method == "Network.requestWillBeSent":
                    params = message.get("params", {})
                    request = params.get("request", {})
                    url = request.get("url", "")
                    headers = request.get("headers", {})
                    
                    if is_interesting_api(url, headers):
                        found_apis.append({
                            "url": url,
                            "method": request.get("method", "GET"),
                            "headers": headers
                        })
                
                elif method == "Network.responseReceived":
                    params = message.get("params", {})
                    response = params.get("response", {})
                    url = response.get("url", "")
                    
                    if is_interesting_api(url):
                        found_apis.append({
                            "url": url,
                            "type": "response",
                            "status": response.get("status", 0)
                        })
            except:
                continue
        
        driver.quit()
        return found_apis
        
    except Exception as e:
        print(f"❌ Hiba: {e}")
        return []

def test_api_variations():
    """API variációk tesztelése - próbálunk rejtett endpoint-okat találni"""
    base_urls = [
        "https://vf.live.vsports.cloud/vflmshop/mobile/",
        "https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/",
        "https://vfdirectdata.live.vsports.cloud//14562/scigamingscigamingcdn/zh/Europe:Berlin/",
    ]
    
    # Érdekes endpoint nevek
    endpoints = [
        "settlements", "results", "outcomes", "resolved",
        "simulation", "generated", "pregenerated",
        "predictions", "probabilities", "calculator",
        "fixture_results", "match_outcomes", "event_settlements",
        "admin", "internal", "debug", "config",
        "metadata", "manifest", "schedule", "timeline",
        "history", "archive", "export", "dump"
    ]
    
    print("🔍 API variációk tesztelése...")
    found = []
    
    for base in base_urls:
        for endpoint in endpoints:
            test_url = base + endpoint
            try:
                resp = requests.get(test_url, timeout=3)
                if resp.status_code == 200:
                    print(f"✅ TALÁLT: {test_url} (status: {resp.status_code})")
                    found.append({
                        "url": test_url,
                        "status": resp.status_code,
                        "content_type": resp.headers.get("content-type", ""),
                        "method": "discovery"
                    })
            except:
                pass
    
    return found

def analyze_existing_apis():
    """Meglévő API-k elemzése - keressünk benne settlement/result mezőket"""
    print("🔍 Meglévő API-k elemzése...")
    
    # Competitions API - lehet benne settlement info
    try:
        comp_url = "https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh"
        comp_data = requests.get(comp_url, timeout=5).json()
        
        # Keresünk settlement/result mezőket
        comp_str = json.dumps(comp_data, indent=2)
        if re.search(r'settlement|result|outcome|resolved', comp_str, re.I):
            print("✅ COMPETITIONS API tartalmaz settlement/result adatokat!")
            print(comp_str[:500])
    except:
        pass
    
    # Timings API
    try:
        time_url = "https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0"
        time_data = requests.get(time_url, timeout=5).json()
        
        time_str = json.dumps(time_data, indent=2)
        if re.search(r'settlement|result|outcome|resolved|generated|simulation', time_str, re.I):
            print("✅ TIMINGS API tartalmaz speciális adatokat!")
            print(time_str[:500])
    except:
        pass
    
    # Full feed API - ez nagy eséllyel tartalmaz mindent
    try:
        feed_url = "https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/3015230/27"
        feed_data = requests.get(feed_url, timeout=5).json()
        
        feed_str = json.dumps(feed_data, indent=2)
        
        # Keresünk érdekes mezőket
        interesting_fields = re.findall(r'"([^"]*(?:settlement|result|outcome|seed|generated|simulation|prediction)[^"]*)":', feed_str, re.I)
        
        if interesting_fields:
            print(f"✅ FULL FEED API tartalmaz {len(set(interesting_fields))} érdekes mezőt:")
            for field in set(interesting_fields)[:10]:
                print(f"   • {field}")
    except:
        pass

def main():
    print("=" * 70)
    print("🎯 HALADÓ API VADÁSZ")
    print("=" * 70)
    print("Rejtett és előre generált adatok keresése\n")
    
    all_found = []
    
    # 1. Hálózati scan
    print("\n📡 1. Hálózati forgalom figyelése...")
    network_apis = deep_network_scan()
    all_found.extend(network_apis)
    print(f"   Találat: {len(network_apis)} API")
    
    # 2. API variációk tesztelése
    print("\n🔍 2. API endpoint variációk tesztelése...")
    discovered_apis = test_api_variations()
    all_found.extend(discovered_apis)
    print(f"   Találat: {len(discovered_apis)} API")
    
    # 3. Meglévő API-k elemzése
    print("\n🔬 3. Meglévő API-k mély elemzése...")
    analyze_existing_apis()
    
    # Kategorizálás
    settlements = [a for a in all_found if re.search(r'settlement', a.get('url', ''), re.I)]
    results = [a for a in all_found if re.search(r'result|outcome', a.get('url', ''), re.I)]
    
    # Mentés
    print("\n💾 Fájlok mentése...")
    
    with open(SAVE_FILE_ADVANCED, 'w', encoding='utf-8') as f:
        for api in all_found:
            f.write(api.get('url', '') + '\n')
    
    with open(SAVE_FILE_SETTLEMENTS, 'w', encoding='utf-8') as f:
        for api in settlements:
            f.write(api.get('url', '') + '\n')
    
    with open(SAVE_FILE_RESULTS, 'w', encoding='utf-8') as f:
        for api in results:
            f.write(api.get('url', '') + '\n')
    
    with open(SAVE_FILE_JSON, 'w', encoding='utf-8') as f:
        json.dump(all_found, f, indent=2, ensure_ascii=False)
    
    # Összefoglaló
    print("\n" + "=" * 70)
    print("📊 ÖSSZEFOGLALÓ")
    print("=" * 70)
    print(f"✅ Összes talált API: {len(all_found)}")
    print(f"🎯 Settlement API-k: {len(settlements)}")
    print(f"📊 Result API-k: {len(results)}")
    
    if all_found:
        print("\n🔥 ÚJ TALÁLATOK (első 10):")
        for i, api in enumerate(all_found[:10], 1):
            print(f"  {i}. {api.get('url', '')}")
    
    print("\n📁 MENTETT FÁJLOK:")
    print(f"  • {SAVE_FILE_ADVANCED}")
    print(f"  • {SAVE_FILE_SETTLEMENTS}")
    print(f"  • {SAVE_FILE_RESULTS}")
    print(f"  • {SAVE_FILE_JSON}")

if __name__ == "__main__":
    main()
