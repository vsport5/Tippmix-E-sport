# 🔗 MÉLYÍTETT API VÉGPONTOK - KATEGORIZÁLT LISTA

**Teljes scan idő:** 10 perc
**Összesen API-k:** 319
**Kategóriák száma:** 20

---

## 🎯 FOGADÁSI SZORZÓK (ODDS)

**Találatok száma:** 16
**Egyedi minták:** 1

1. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_odds2/{MATCH_ID}

---

## 📊 CSAPAT STATISZTIKÁK (Utolsó mérkőzések)

**Találatok száma:** 16
**Egyedi minták:** 1

1. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/{TEAM_ID}/5

---

## ⚔️ HEAD-TO-HEAD (Egymás elleni)

**Találatok száma:** 16
**Egyedi minták:** 13

1. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/{TEAM_ID}/276501/5
2. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/{TEAM_ID}/276502/5
3. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/{TEAM_ID}/276503/5
4. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/{TEAM_ID}/276505/5
5. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/{TEAM_ID}/276507/5
6. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/{TEAM_ID}/276508/5
7. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/{TEAM_ID}/276509/5
8. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/{TEAM_ID}/276510/5
9. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/{TEAM_ID}/276511/5
10. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/{TEAM_ID}/276512/5
11. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/{TEAM_ID}/276513/5
12. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/{TEAM_ID}/276515/5
13. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/{TEAM_ID}/276516/5

---

## 🔥 TELJES MÉRKŐZÉS FEED

**Találatok száma:** 2
**Egyedi minták:** 2

1. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{SEASON_ID}/1
2. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{SEASON_ID}/30

---

## ⚡ ÉLŐ EREDMÉNYEK

**Találatok száma:** 2
**Egyedi minták:** 2

1. https://vfdirectdata.live.vsports.cloud//14562/scigamingscigamingcdn/zh/Europe:Berlin/vf_livescore/{SEASON_ID}/league/1
2. https://vfdirectdata.live.vsports.cloud//14562/scigamingscigamingcdn/zh/Europe:Berlin/vf_livescore/{SEASON_ID}/league/30

---

## 🆔 MÉRKŐZÉS AZONOSÍTÓK

**Találatok száma:** 5
**Egyedi minták:** 5

1. https://vf.live.vsports.cloud/vflmshop/mobile/eventIds.json?clientid=4997&lang=zh&seasonid=3015344&stagetype=1&matchset=30
2. https://vf.live.vsports.cloud/vflmshop/mobile/eventIds.json?clientid=4997&lang=zh&seasonid=3015403&stagetype=1&matchset=1
3. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.data.eventIds/vswidgets/
4. scigamingscigamingcdn/zh/components/vswidgets.core.data.eventIds/vswidgets/
5. vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.data.eventIds/vswidgets/

---

## 🏆 VERSENYEK / SZEZONOK

**Találatok száma:** 1
**Egyedi minták:** 1

1. https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh

---

## ⏰ IDŐZÍTÉSEK

**Találatok száma:** 8
**Egyedi minták:** 8

1. https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0
2. https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=1761552577
3. https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=1761552707
4. https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=1761552767
5. https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=1761552827
6. https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=1761552887
7. https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=1761553127
8. https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=1761553137

---

## 📅 MÉRKŐZÉS FÁZISOK

**Találatok száma:** 1
**Egyedi minták:** 1

1. https://vf.live.vsports.cloud/vflmshop/mobile/phases?clientid=4997&lang=zh

---

## ⚙️ BEÁLLÍTÁSOK

**Találatok száma:** 1
**Egyedi minták:** 1

1. https://vf.live.vsports.cloud/vflmshop/mobile/settings?clientid=4997&lang=zh

---

## 📈 TABELLA / ÁLLÁSOK

**Találatok száma:** 3
**Egyedi minták:** 3

1. https://vfcommon.live.vsports.cloud/playerclass/stable/playerclasskey/index.php?library=flowplayer7_27&stoken=b0a9fde6fd03ded63eeeef0329c79d60&etoken=5d716a69ee37f5a37795c2084dad6e1d&domain=dmZzY2lnYW1pbmcuYWl0Y2xvdWQuZGU=
2. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_tournament_livetablebyseasonandround/{SEASON_ID}/1
3. https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_tournament_livetablebyseasonandround/{SEASON_ID}/30

---

## 📺 WIDGET API-K

**Találatok száma:** 69
**Egyedi minták:** 69

1. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.area/vswidgets/
2. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.calltoaction/vswidgets/
3. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.chunkname/vswidgets/
4. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.data.eventIds/vswidgets/
5. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.data.feed/vswidgets/
6. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.data.matchProbabilities/vswidgets/
7. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.iframe/vswidgets/
8. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.image/vswidgets/
9. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.info-base/vswidgets/
10. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.maintenance/vswidgets/
11. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.matchManager/vswidgets/
12. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.matchdayselector/vswidgets/
13. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.package/vswidgets/
14. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.progressbar/vswidgets/
15. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.resolvedmarkets/vswidgets/
16. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.retailoddsmulti/vswidgets/
17. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.text/vswidgets/
18. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.videoplayer/vswidgets/
19. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.vf.timeline/vswidgets/
20. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.vfc.livesettlements/vswidgets/

... és még 49 minta

---

## 🏅 SPORTRADAR API

**Találatok száma:** 1
**Egyedi minták:** 1

1. https://s5.sir.sportradar.com/scigamingvirtuals/zh/1/season/%season_id%/h2h/%team1%/%team2%

---

## 🎬 VIDEÓ PLAYLIST

**Találatok száma:** 3
**Egyedi minták:** 3

1. https://retailvideo-s01live-vs001.akamaized.net/live/_definst_/vflm_25_xb_scigaming-1024x576-1000k-v2_channel7/chunklist.m3u8
2. https://retailvideo-s02live-vs001.akamaized.net/live/_definst_/vflm_25_xb_scigaming-1024x576-1000k-v2_channel7/chunklist.m3u8
3. https://retailvideolive-vs001.akamaized.net/live/vflm_25_xb_scigaming-1024x576-1000k-v2_channel7/playlist.m3u8

---

## 📈 ANALYTICS / TRACKING

**Találatok száma:** 7
**Egyedi minták:** 7

1. https://vgt.live.vsports.cloud/piwik//piwik.php?action_name=Virtual%20Football&idsite=2179&rec=1&r=535641&h=8&m=9&s=25&url=https%3A%2F%2Fvfscigaming.aitcloud.de%2Fvflmshop%2Fretail%2Findex%3Fchannel%3D7%26clientid%3D4997%26lang%3Dzh%26screen%3Dbetradar_vflm_one_screen%26style%3Dscigamingcdn&_id=&_idn=1&send_image=0&_refts=0&pdf=1&qt=0&realp=0&wma=0&fla=0&java=0&ag=0&cookie=1&res=800x600&pv_id=4wqClO&pf_net=407&pf_srv=139&pf_tfr=8&pf_dm1=1231&pf_dm2=2&pf_onl=0&uadata=%7B%22fullVersionList%22%3A%5B%7B%22brand%22%3A%22Not)A%3BBrand%22%2C%22version%22%3A%228.0.0.0%22%7D%2C%7B%22brand%22%3A%22Chromium%22%2C%22version%22%3A%22138.0.7204.100%22%7D%5D%2C%22mobile%22%3Afalse%2C%22model%22%3A%22%22%2C%22platform%22%3A%22Linux%22%2C%22platformVersion%22%3A%226.2.16%22%7D
2. https://vgt.live.vsports.cloud/piwik//piwik.php?e_c=Video_Controlbar&e_a=playPauseButton&ca=1&idsite=2179&rec=1&r=007193&h=8&m=12&s=59&url=https%3A%2F%2Fvfscigaming.aitcloud.de%2Fvflmshop%2Fretail%2Findex%3Fchannel%3D7%26clientid%3D4997%26lang%3Dzh%26screen%3Dbetradar_vflm_one_screen%26style%3Dscigamingcdn&_id=&_idn=1&send_image=0&_refts=0&pdf=1&qt=0&realp=0&wma=0&fla=0&java=0&ag=0&cookie=1&res=800x600&pv_id=4wqClO&uadata=%7B%22brands%22%3A%5B%7B%22brand%22%3A%22Not)A%3BBrand%22%2C%22version%22%3A%228%22%7D%2C%7B%22brand%22%3A%22Chromium%22%2C%22version%22%3A%22138%22%7D%5D%2C%22platform%22%3A%22Linux%22%7D
3. https://vgt.live.vsports.cloud/piwik//piwik.php?e_c=Video_Controlbar&e_a=playPauseButton&ca=1&idsite=2179&rec=1&r=251337&h=8&m=13&s=48&url=https%3A%2F%2Fvfscigaming.aitcloud.de%2Fvflmshop%2Fretail%2Findex%3Fchannel%3D7%26clientid%3D4997%26lang%3Dzh%26screen%3Dbetradar_vflm_one_screen%26style%3Dscigamingcdn&_id=&_idn=1&send_image=0&_refts=0&pdf=1&qt=0&realp=0&wma=0&fla=0&java=0&ag=0&cookie=1&res=800x600&pv_id=4wqClO&uadata=%7B%22brands%22%3A%5B%7B%22brand%22%3A%22Not)A%3BBrand%22%2C%22version%22%3A%228%22%7D%2C%7B%22brand%22%3A%22Chromium%22%2C%22version%22%3A%22138%22%7D%5D%2C%22platform%22%3A%22Linux%22%7D
4. https://vgt.live.vsports.cloud/piwik//piwik.php?e_c=Video_Controlbar&e_a=playPauseButton&ca=1&idsite=2179&rec=1&r=263538&h=8&m=18&s=48&url=https%3A%2F%2Fvfscigaming.aitcloud.de%2Fvflmshop%2Fretail%2Findex%3Fchannel%3D7%26clientid%3D4997%26lang%3Dzh%26screen%3Dbetradar_vflm_one_screen%26style%3Dscigamingcdn&_id=&_idn=1&send_image=0&_refts=0&pdf=1&qt=0&realp=0&wma=0&fla=0&java=0&ag=0&cookie=1&res=800x600&pv_id=4wqClO&uadata=%7B%22brands%22%3A%5B%7B%22brand%22%3A%22Not)A%3BBrand%22%2C%22version%22%3A%228%22%7D%2C%7B%22brand%22%3A%22Chromium%22%2C%22version%22%3A%22138%22%7D%5D%2C%22platform%22%3A%22Linux%22%7D
5. https://vgt.live.vsports.cloud/piwik//piwik.php?e_c=Video_Controlbar&e_a=playPauseButton&ca=1&idsite=2179&rec=1&r=337383&h=8&m=11&s=50&url=https%3A%2F%2Fvfscigaming.aitcloud.de%2Fvflmshop%2Fretail%2Findex%3Fchannel%3D7%26clientid%3D4997%26lang%3Dzh%26screen%3Dbetradar_vflm_one_screen%26style%3Dscigamingcdn&_id=&_idn=1&send_image=0&_refts=0&pdf=1&qt=0&realp=0&wma=0&fla=0&java=0&ag=0&cookie=1&res=800x600&pf_net=407&pf_srv=139&pf_tfr=8&pf_dm1=1231&pf_dm2=2&pf_onl=0&pv_id=4wqClO&uadata=%7B%22brands%22%3A%5B%7B%22brand%22%3A%22Not)A%3BBrand%22%2C%22version%22%3A%228%22%7D%2C%7B%22brand%22%3A%22Chromium%22%2C%22version%22%3A%22138%22%7D%5D%2C%22platform%22%3A%22Linux%22%7D
6. https://vgt.live.vsports.cloud/piwik//piwik.php?e_c=Video_Controlbar&e_a=playPauseButton&ca=1&idsite=2179&rec=1&r=721146&h=8&m=12&s=49&url=https%3A%2F%2Fvfscigaming.aitcloud.de%2Fvflmshop%2Fretail%2Findex%3Fchannel%3D7%26clientid%3D4997%26lang%3Dzh%26screen%3Dbetradar_vflm_one_screen%26style%3Dscigamingcdn&_id=&_idn=1&send_image=0&_refts=0&pdf=1&qt=0&realp=0&wma=0&fla=0&java=0&ag=0&cookie=1&res=800x600&pv_id=4wqClO&uadata=%7B%22brands%22%3A%5B%7B%22brand%22%3A%22Not)A%3BBrand%22%2C%22version%22%3A%228%22%7D%2C%7B%22brand%22%3A%22Chromium%22%2C%22version%22%3A%22138%22%7D%5D%2C%22platform%22%3A%22Linux%22%7D
7. https://vgt.live.vsports.cloud/piwik//piwik.php?e_c=Video_Controlbar&e_a=playPauseButton&ca=1&idsite=2179&rec=1&r=901575&h=8&m=14&s=48&url=https%3A%2F%2Fvfscigaming.aitcloud.de%2Fvflmshop%2Fretail%2Findex%3Fchannel%3D7%26clientid%3D4997%26lang%3Dzh%26screen%3Dbetradar_vflm_one_screen%26style%3Dscigamingcdn&_id=&_idn=1&send_image=0&_refts=0&pdf=1&qt=0&realp=0&wma=0&fla=0&java=0&ag=0&cookie=1&res=800x600&pv_id=4wqClO&uadata=%7B%22brands%22%3A%5B%7B%22brand%22%3A%22Not)A%3BBrand%22%2C%22version%22%3A%228%22%7D%2C%7B%22brand%22%3A%22Chromium%22%2C%22version%22%3A%22138%22%7D%5D%2C%22platform%22%3A%22Linux%22%7D

---

## 👕 MEZEK

**Találatok száma:** 1
**Egyedi minták:** 1

1. https://vf.live.vsports.cloud/vflmshop/mobile/teamJerseyAssignments.json?clientid=4997

---

## 🎮 PLAYER

**Találatok száma:** 4
**Egyedi minták:** 4

1. https://vfcommon.live.vsports.cloud/playerclass/stable/playerclasskey/index.php?library=flowplayer7_27&stoken=b0a9fde6fd03ded63eeeef0329c79d60&etoken=5d716a69ee37f5a37795c2084dad6e1d&domain=dmZzY2lnYW1pbmcuYWl0Y2xvdWQuZGU=
2. https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.videoplayer/vswidgets/
3. scigamingscigamingcdn/zh/components/vswidgets.core.videoplayer/vswidgets/
4. vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.videoplayer/vswidgets/

---

## 🎨 TEMPLATE

**Találatok száma:** 1
**Egyedi minták:** 1

1. https://vfscigaming.aitcloud.de/vflmshop/retail/templates

---

## 🎥 VIDEÓ SZEGMENSEK

**Találatok száma:** 165
**Egyedi minták:** 2

**Minta URL-ek (a teljes 165 közül):**

1. `https://retailvideo-s01live-vs001.akamaized.net/live/_definst_/vflm_25_xb_scigaming-1024x576-1000k-v2_channel7/media_{N}.ts`
2. `https://retailvideo-s02live-vs001.akamaized.net/live/_definst_/vflm_25_xb_scigaming-1024x576-1000k-v2_channel7/media_{N}.ts`

... és még 160 hasonló URL

---

## 📦 EGYÉB

**Találatok száma:** 4
**Egyedi minták:** 4

1. https://vfscigaming.aitcloud.de/vflmshop/retail/index?channel=7&amp;clientid=4997&amp;lang=zh&amp;screen=betradar_vflm_one_screen&amp;style=scigamingcdn#f1
2. https://vfscigaming.aitcloud.de/vflmshop/retail/index?channel=7&clientid=4997&lang=zh&screen=betradar_vflm_one_screen&style=scigamingcdn
3. scigaming.aitcloud.de/vflmshop/retail/index?channel=7&amp;clientid=4997&amp;lang=zh&amp;screen=betradar_vflm_one_screen&amp;style=scigamingcdn#f1
4. scigamingvirtuals/zh/1/season/%season_id%/h2h/%team1%/%team2%

---

## 📊 ÖSSZEFOGLALÓ TÁBLÁZAT

| Kategória | API-k száma | Egyedi minták |
|-----------|-------------|---------------|
| FOGADÁSI SZORZÓK (ODDS) | 16 | 1 |
| CSAPAT STATISZTIKÁK (Utolsó mérkőzések) | 16 | 1 |
| HEAD-TO-HEAD (Egymás elleni) | 16 | 13 |
| TELJES MÉRKŐZÉS FEED | 2 | 2 |
| ÉLŐ EREDMÉNYEK | 2 | 2 |
| MÉRKŐZÉS AZONOSÍTÓK | 5 | 5 |
| VERSENYEK / SZEZONOK | 1 | 1 |
| IDŐZÍTÉSEK | 8 | 8 |
| MÉRKŐZÉS FÁZISOK | 1 | 1 |
| BEÁLLÍTÁSOK | 1 | 1 |
| TABELLA / ÁLLÁSOK | 3 | 3 |
| WIDGET API-K | 69 | 69 |
| SPORTRADAR API | 1 | 1 |
| VIDEÓ PLAYLIST | 3 | 3 |
| ANALYTICS / TRACKING | 7 | 7 |
| MEZEK | 1 | 1 |
| PLAYER | 4 | 4 |
| TEMPLATE | 1 | 1 |
| VIDEÓ SZEGMENSEK | 165 | 2 |
| EGYÉB | 4 | 4 |

---

**Készítve:** 2025-10-27
**Mélyített scan:** 10 perc / 600 másodperc
**Scanner:** deep_api_scanner.py