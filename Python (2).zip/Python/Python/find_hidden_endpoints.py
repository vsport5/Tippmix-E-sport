# (ide jön a teljes kód, amit fent bemásoltál)
