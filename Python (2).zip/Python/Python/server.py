# server.py
# Egyszerű HTTP szerver az API scanner eredmények megjelenítésére

from http.server import HTTPServer, SimpleHTTPRequestHandler
import os

class CORSRequestHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        super().end_headers()
    
    def log_message(self, format, *args):
        # Egyszerűsített logging
        print(f"[HTTP] {args[0]}")

def run_server(port=5000):
    server_address = ('0.0.0.0', port)
    httpd = HTTPServer(server_address, CORSRequestHandler)
    print(f"🌐 API Scanner Dashboard")
    print(f"📊 Szerver fut: http://0.0.0.0:{port}")
    print(f"📁 Dokumentációk:")
    print(f"   • http://0.0.0.0:{port}/")
    print(f"   • http://0.0.0.0:{port}/MELYITETT_API_LINKEK.md")
    print(f"   • http://0.0.0.0:{port}/deep_api_details.json")
    print("")
    httpd.serve_forever()

if __name__ == "__main__":
    run_server()
