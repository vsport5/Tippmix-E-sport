
import requests
import json
from datetime import datetime

def analyze_past_matches():
    """Múltbeli mérkőzések elemzése - keresünk seed/generated mezőket"""
    
    print("=" * 70)
    print("🔍 MÚLTBELI MÉRKŐZÉSEK ELEMZÉSE")
    print("=" * 70)
    
    # Aktuális szezon és forduló
    comp_data = requests.get(
        "https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh"
    ).json()
    
    season_id = comp_data["next_competitions"][0]["competition_id"]
    
    timings_data = requests.get(
        "https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0"
    ).json()
    
    current_round = timings_data["timings"][0]["matches"][0]["matchset_nr"]
    
    print(f"\n📍 Aktuális: Szezon {season_id}, Forduló {current_round}")
    
    # VISSZAMENŐLEG elemezzük a fordulókat
    findings = []
    
    for past_round in range(max(1, current_round - 5), current_round):
        print(f"\n🔙 Forduló {past_round} elemzése...")
        
        url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{season_id}/{past_round}"
        
        try:
            resp = requests.get(url, timeout=10)
            data = resp.json()
            
            matches_dict = data["doc"][0]["data"]["1"]["realcategories"]["1111"]["tournaments"]["56369"]["matches"]
            
            for match_id, match in matches_dict.items():
                result = match.get("result", {})
                home_score = result.get("home")
                away_score = result.get("away")
                winner = result.get("winner")
                
                # Ha van eredmény (lezárt meccs)
                if home_score is not None and away_score is not None:
                    
                    # Keresünk SEED/GENERATED mezőket
                    match_str = json.dumps(match, indent=2)
                    
                    interesting = {
                        "match_id": match_id,
                        "round": past_round,
                        "home": match["teams"]["home"]["name"],
                        "away": match["teams"]["away"]["name"],
                        "score": f"{home_score}-{away_score}",
                        "winner": winner,
                        "fields_found": []
                    }
                    
                    # Keresünk rejtett mezőket
                    search_patterns = [
                        'seed', 'generated', 'random', 'simulation',
                        'predetermined', 'fixture', 'outcome_id',
                        'result_id', 'settlement_id', 'internal',
                        'config', 'metadata', '_gen', '_sim'
                    ]
                    
                    for pattern in search_patterns:
                        if pattern in match_str.lower():
                            interesting["fields_found"].append(pattern)
                    
                    # Kiírjuk az ÖSSZES mezőt
                    all_keys = set()
                    def get_all_keys(obj, prefix=""):
                        if isinstance(obj, dict):
                            for key, value in obj.items():
                                full_key = f"{prefix}.{key}" if prefix else key
                                all_keys.add(full_key)
                                get_all_keys(value, full_key)
                        elif isinstance(obj, list) and obj:
                            get_all_keys(obj[0], prefix)
                    
                    get_all_keys(match)
                    interesting["all_fields"] = sorted(list(all_keys))
                    
                    findings.append(interesting)
                    
                    print(f"   ✅ Mérkőzés {match_id}: {home_score}-{away_score}")
                    if interesting["fields_found"]:
                        print(f"      🚨 ÉRDEKES MEZŐK: {', '.join(interesting['fields_found'])}")
        
        except Exception as e:
            print(f"   ❌ Hiba: {e}")
    
    # Összefoglaló
    print("\n" + "=" * 70)
    print("📊 ÖSSZEFOGLALÓ")
    print("=" * 70)
    
    if findings:
        print(f"\n✅ {len(findings)} lezárt mérkőzés találva")
        
        # Van-e bármelyikben érdekes mező?
        with_interesting = [f for f in findings if f["fields_found"]]
        
        if with_interesting:
            print(f"\n🚨 {len(with_interesting)} mérkőzésben ÉRDEKES MEZŐK:")
            for f in with_interesting:
                print(f"\n   Meccs: {f['home']} {f['score']} {f['away']}")
                print(f"   Mezők: {', '.join(f['fields_found'])}")
        else:
            print("\n❌ EGYIK MÉRKŐZÉSBEN SEM találtam seed/generated mezőket")
            print("\n💡 KÖVETKEZTETÉS:")
            print("   • Az eredmények NEM tárolódnak a full_feed API-ban")
            print("   • Vagy külön API-ban vannak (settlements, results)")
            print("   • Vagy backend-en generálódnak real-time")
        
        # Első mérkőzés ÖSSZES mezője
        if findings:
            print(f"\n📋 EGY LEZÁRT MÉRKŐZÉS ÖSSZES MEZŐJE ({len(findings[0]['all_fields'])} db):")
            for field in findings[0]["all_fields"][:30]:
                print(f"   • {field}")
            if len(findings[0]["all_fields"]) > 30:
                print(f"   ... és még {len(findings[0]['all_fields']) - 30} mező")
    
    else:
        print("\n❌ Nem találtam lezárt mérkőzéseket")
    
    # Mentés
    with open("past_matches_analysis.json", "w", encoding="utf-8") as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)
    
    print("\n💾 Részletes elemzés: past_matches_analysis.json")
    
    return findings

if __name__ == "__main__":
    analyze_past_matches()
