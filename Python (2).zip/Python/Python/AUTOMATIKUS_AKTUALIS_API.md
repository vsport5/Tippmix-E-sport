# 🔄 AUTOMATIKUS AKTUÁLIS SZEZON & FORDULÓ API-K

## ✅ EZEK MINDIG AZ AKTUÁLIS ADATOKAT ADJÁK!

---

## 🏆 1. COMPETITIONS API (Legfontosabb!)

### URL:
```
https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh
```

### Mit ad vissza:
- **`next_competitions`** - A JELENLEG FUTÓ SZEZON (automatikusan frissül!)
- **`past_competitions`** - Előző szezonok listája

### Példa válasz:
```json
{
    "next_competitions": [
        {
            "competition_id": 3015230,           ← AZ AKTUÁLIS SZEZON ID!
            "continuous_counter": 21659,         ← Folyamatos számláló
            "competition_name": "21659",
            "start_datetime": 1761512867,
            "end_datetime": 1761526187,
            "group_count": 1,
            "clubs_per_group": 16,
            "groupphase_rematch": 1
        }
    ],
    "past_competitions": [
        {
            "competition_id": 3015175,           ← Előző szezon
            "continuous_counter": 21658,
            ...
        }
    ]
}
```

### 🎯 HASZNÁLAT:
1. Lekéred ezt az API-t
2. Kiveszed a `next_competitions[0].competition_id` értéket
3. Ez MINDIG az aktuális szezon ID!
4. Automatikusan frissül minden új szezonnál!

---

## ⏱️ 2. TIMINGS API (Real-time mérkőzések)

### URL:
```
https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0
```

### Mit ad vissza:
- **Aktuális mérkőzések** listája
- **competition_id** - Az aktuális szezon
- **matchset_nr** - Az aktuális forduló száma
- **match_start_datetime** - Mikor kezdődik
- **betstop_datetime** - Meddig lehet fogadni

### Példa válasz:
```json
{
    "timings": [
        {
            "phase_name": "pre_match",
            "matches": [
                {
                    "id": 1390683020,
                    "matchset_nr": 27,                    ← AKTUÁLIS FORDULÓ!
                    "competition_id": 3015230,            ← AKTUÁLIS SZEZON!
                    "continuous_counter": 21659,
                    "betstop_datetime": 1761524607,
                    "match_start_datetime": 1761524617,
                    "home_team_id": 8982007,
                    "away_team_id": 8982008
                },
                {
                    "id": 1390683028,
                    "matchset_nr": 28,                    ← KÖVETKEZŐ FORDULÓ!
                    "competition_id": 3015230,
                    ...
                }
            ]
        }
    ]
}
```

### 🎯 HASZNÁLAT:
1. Lekéred ezt az API-t
2. Az első match adja az aktuális fordulót
3. Automatikusan frissül real-time!

---

## 🔥 3. KOMBINÁLT STRATÉGIA (Ajánlott!)

### Lépések:

#### 1️⃣ Aktuális szezon ID lekérése:
```python
import requests

# Aktuális szezon
competitions = requests.get(
    "https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh"
).json()

current_season_id = competitions["next_competitions"][0]["competition_id"]
print(f"Aktuális szezon: {current_season_id}")  # pl: 3015230
```

#### 2️⃣ Aktuális forduló lekérése:
```python
# Aktuális forduló és mérkőzések
timings = requests.get(
    "https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0"
).json()

current_round = timings["timings"][0]["matches"][0]["matchset_nr"]
print(f"Aktuális forduló: {current_round}")  # pl: 27
```

#### 3️⃣ Használd ezeket az értékeket dinamikusan:
```python
# Most már dinamikusan használhatod más API-kban
event_ids_url = f"https://vf.live.vsports.cloud/vflmshop/mobile/eventIds.json?clientid=4997&lang=zh&seasonid={current_season_id}&stagetype=1&matchset={current_round}"

odds_url = f"https://vfdirectdata.live.vsports.cloud//14562/scigamingscigamingcdn/zh/Europe:Berlin/vf_livescore/{current_season_id}/league/{current_round}"

full_feed_url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{current_season_id}/{current_round}"
```

---

## 📊 ELŐNYÖK:

✅ **Nincs kézi frissítés** - Automatikusan mindig az aktuális adatokat kapod  
✅ **Szezon váltásnál** - Egyből az új szezont mutatja  
✅ **Forduló váltásnál** - Real-time frissül  
✅ **Megbízható** - A hivatalos API-k ezeket használják  
✅ **Timestamp** - Megkapod az időpontokat is  

---

## 🎲 PÉLDA HASZNÁLAT FOGADÁSHOZ:

```python
import requests
import time

def get_current_season_and_round():
    """Mindig az aktuális szezon és forduló lekérése"""
    
    # 1. Aktuális szezon
    comp_api = "https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh"
    competitions = requests.get(comp_api).json()
    season_id = competitions["next_competitions"][0]["competition_id"]
    
    # 2. Aktuális forduló
    time_api = "https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0"
    timings = requests.get(time_api).json()
    
    current_matches = timings["timings"][0]["matches"]
    current_round = current_matches[0]["matchset_nr"]
    
    return season_id, current_round

# Használat
season, round_nr = get_current_season_and_round()
print(f"Szezon: {season}, Forduló: {round_nr}")

# Dinamikus URL-ek
full_feed = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{season}/{round_nr}"
print(full_feed)
```

---

## 🔔 FRISSÍTÉSI GYAKORISÁG:

- **Competitions API**: ~3-4 óránként új szezon (amikor az előző véget ér)
- **Timings API**: ~7-8 percenként új forduló (mérkőzések között)
- **Real-time**: Másodpercenként lehet lekérdezni

---

## 💡 FONTOS MEGJEGYZÉSEK:

1. **A `timings` API mindig a következő 2-3 mérkőzést mutatja előre**
2. **A `competitions` API tartalmazza a kezdési/befejezési időpontokat**
3. **A `continuous_counter` egy folyamatos számláló, ami SOHA nem áll vissza**
4. **A `competition_id` minden szezonnál változik**
5. **A `matchset_nr` 1-től 30-ig megy általában (egy szezonban)**

---

## ✅ ÖSSZEFOGLALÁS

**Ezeket az API-kat használd MINDIG:**

1. **Aktuális szezon:** `competitions` API → `next_competitions[0].competition_id`
2. **Aktuális forduló:** `timings` API → `matches[0].matchset_nr`
3. **Dinamikus URL építés:** Használd ezeket az értékeket más API-kban

**Így a scraper rendszered SOHA nem fog elavult season/round ID-kat használni!** 🎉

---

**Készítve:** 2025-10-27  
**Tesztelve:** ✅ Működik  
**Auto-update:** ✅ Igen
