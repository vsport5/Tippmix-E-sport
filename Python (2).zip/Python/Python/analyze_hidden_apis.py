import requests
import json

print("="*70)
print("🔍 REJTETT API-K RÉSZLETES ELEMZÉSE")
print("="*70)

interesting_apis = {
    'predictions': 'https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/predictions',
    'pregenerated': 'https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/pregenerated',
    'generated': 'https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/generated',
    'simulation': 'https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/simulation',
    'settlements': 'https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/settlements',
    'results': 'https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/results',
    'outcomes': 'https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/outcomes',
    'probabilities': 'https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/probabilities',
    'admin': 'https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/admin',
    'internal': 'https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/internal',
    'debug': 'https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/debug',
    'config': 'https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/config',
}

summary = {}

for name, url in interesting_apis.items():
    print("\n" + "="*70)
    print(f"🔍 {name.upper()} API ELEMZÉSE")
    print("="*70)
    print(f"URL: {url}")
    
    try:
        resp = requests.get(url, timeout=10)
        print(f"Status: {resp.status_code}")
        print(f"Content-Type: {resp.headers.get('content-type', 'unknown')}")
        print(f"Méret: {len(resp.text)} karakter")
        
        summary[name] = {
            "url": url,
            "status": resp.status_code,
            "size": len(resp.text),
            "type": "unknown"
        }
        
        try:
            data = resp.json()
            print(f"\n✅ VALID JSON VÁLASZ!")
            
            if isinstance(data, dict):
                print(f"Kulcsok: {list(data.keys())[:10]}")
                summary[name]["type"] = "json"
                summary[name]["keys"] = list(data.keys())
            elif isinstance(data, list):
                print(f"Lista, elemek száma: {len(data)}")
                summary[name]["type"] = "json_array"
                summary[name]["count"] = len(data)
            
            json_str = json.dumps(data, indent=2, ensure_ascii=False)
            print(f"\nJSON előnézet (első 400 karakter):")
            print(json_str[:400])
            
            if len(json_str) > 50:
                with open(f'hidden_{name}.json', 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                print(f"\n💾 Mentve: hidden_{name}.json")
                summary[name]["saved"] = True
            else:
                print(f"\n⚠️ Üres vagy túl kicsi válasz, nem mentve")
                summary[name]["saved"] = False
            
        except Exception as e:
            print(f"\n⚠️ NEM JSON válasz")
            print(f"Első 300 karakter:")
            print(resp.text[:300])
            summary[name]["type"] = "non_json"
            
    except Exception as e:
        print(f"❌ Hiba: {e}")
        summary[name] = {"error": str(e)}

print("\n" + "="*70)
print("📊 ÖSSZEFOGLALÓ")
print("="*70)

for name, info in summary.items():
    print(f"\n{name.upper()}:")
    if "error" in info:
        print(f"  ❌ {info['error']}")
    else:
        print(f"  Status: {info['status']}")
        print(f"  Méret: {info['size']} karakter")
        print(f"  Típus: {info['type']}")
        if info.get('saved'):
            print(f"  💾 Mentve: hidden_{name}.json")

with open('hidden_apis_summary.json', 'w', encoding='utf-8') as f:
    json.dump(summary, f, indent=2, ensure_ascii=False)

print("\n💾 Teljes összefoglaló: hidden_apis_summary.json")
