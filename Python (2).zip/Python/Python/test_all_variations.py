import requests
import json
import time

print("="*70)
print("🔥 TELJES KÖRŰ API VARIÁCIÓ TESZTELÉS")
print("="*70)
print("Minden lehetséges kombinációt kipróbálunk!\n")

# 1. Aktuális adatok lekérése
print("📍 1. Aktuális season/round/match ID-k lekérése...")
try:
    comp_url = "https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh"
    comp_data = requests.get(comp_url, timeout=5).json()
    season_id = comp_data["next_competitions"][0]["competition_id"]
    print(f"   ✅ Season ID: {season_id}")
    
    time_url = "https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0"
    time_data = requests.get(time_url, timeout=5).json()
    
    # Minden match ID összegyűjtése
    match_ids = []
    for timing in time_data.get("timings", []):
        for match in timing.get("matches", []):
            match_ids.append(match["id"])
    
    current_round = time_data["timings"][0]["matches"][0]["matchset_nr"]
    print(f"   ✅ Aktuális forduló: {current_round}")
    print(f"   ✅ Match ID-k: {len(match_ids)} db")
    if match_ids:
        print(f"   ✅ Első match ID: {match_ids[0]}")
    
except Exception as e:
    print(f"   ❌ Hiba: {e}")
    season_id = "3015230"
    current_round = 27
    match_ids = [1390728672]
    print(f"   ⚠️ Fallback adatok használata")

# 2. API endpoint nevek
endpoints = [
    "predictions",
    "pregenerated", 
    "generated",
    "simulation",
    "settlements",
    "results",
    "outcomes",
    "probabilities"
]

# 3. Base URL-ek
base_urls = [
    "https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/",
    "https://vfdirectdata.live.vsports.cloud//14562/scigamingscigamingcdn/zh/Europe:Berlin/",
]

# 4. Paraméter variációk generálása
param_variations = [
    "",  # Paraméter nélkül (már tudjuk, hogy nem működik)
    f"{season_id}",
    f"{current_round}",
    f"{season_id}/{current_round}",
    f"{current_round}/{season_id}",
]

# Match ID-kat is hozzáadjuk (első 3)
for match_id in match_ids[:3]:
    param_variations.extend([
        f"{match_id}",
        f"{season_id}/{match_id}",
        f"{match_id}/{season_id}",
        f"{season_id}/{current_round}/{match_id}",
        f"{match_id}/{current_round}",
    ])

print(f"\n🔍 2. Tesztelés megkezdése...")
print(f"   Endpoint-ok: {len(endpoints)}")
print(f"   Base URL-ek: {len(base_urls)}")
print(f"   Paraméter variációk: {len(param_variations)}")
print(f"   Összes teszt: {len(endpoints) * len(base_urls) * len(param_variations)}\n")

successful_apis = []
test_count = 0

for endpoint in endpoints:
    print(f"\n{'='*70}")
    print(f"🎯 {endpoint.upper()} endpoint tesztelése...")
    print(f"{'='*70}")
    
    for base_url in base_urls:
        for params in param_variations:
            test_count += 1
            
            if params:
                full_url = f"{base_url}{endpoint}/{params}"
            else:
                full_url = f"{base_url}{endpoint}"
            
            try:
                resp = requests.get(full_url, timeout=3)
                
                # Ellenőrizzük, hogy nem exception-t kaptunk-e
                is_valid = False
                try:
                    data = resp.json()
                    
                    # Ha exception van benne, az nem jó
                    if isinstance(data, dict) and "doc" in data:
                        doc = data["doc"]
                        if isinstance(doc, list) and len(doc) > 0:
                            if doc[0].get("event") != "exception":
                                is_valid = True
                            elif "exception" not in str(data).lower():
                                is_valid = True
                    elif resp.status_code == 200 and len(resp.text) > 100:
                        is_valid = True
                        
                except:
                    pass
                
                if is_valid:
                    print(f"\n🚨🚨🚨 SIKERES TALÁLAT! 🚨🚨🚨")
                    print(f"URL: {full_url}")
                    print(f"Status: {resp.status_code}")
                    print(f"Méret: {len(resp.text)} karakter")
                    
                    try:
                        data = resp.json()
                        print(f"JSON preview:")
                        print(json.dumps(data, indent=2, ensure_ascii=False)[:500])
                        
                        # Mentés
                        filename = f"FOUND_{endpoint}_{params.replace('/', '_')}.json"
                        with open(filename, 'w', encoding='utf-8') as f:
                            json.dump(data, f, indent=2, ensure_ascii=False)
                        print(f"💾 MENTVE: {filename}")
                        
                        successful_apis.append({
                            "endpoint": endpoint,
                            "url": full_url,
                            "params": params,
                            "filename": filename
                        })
                    except:
                        pass
                        
            except:
                pass
            
            # Progress minden 50. tesztnél
            if test_count % 50 == 0:
                print(f"   ... {test_count} teszt elvégezve ...")

print("\n" + "="*70)
print("📊 VÉGEREDMÉNY")
print("="*70)
print(f"✅ Összes teszt: {test_count}")
print(f"🎯 Sikeres találatok: {len(successful_apis)}")

if successful_apis:
    print(f"\n🔥🔥🔥 SIKERES API-K: 🔥🔥🔥")
    for api in successful_apis:
        print(f"\n  Endpoint: {api['endpoint']}")
        print(f"  URL: {api['url']}")
        print(f"  Fájl: {api['filename']}")
else:
    print("\n⚠️ Sajnos egyik variáció sem működött...")
    print("\n💡 KÖVETKEZŐ LÉPÉSEK:")
    print("   1. Próbáljuk meg más URL struktúrákat")
    print("   2. Keressünk URL mintákat a JavaScript kódban")
    print("   3. Figyeljük meg a hálózati forgalmat élő meccsnél")

# Mentés
with open('api_variation_test_results.json', 'w', encoding='utf-8') as f:
    json.dump({
        "total_tests": test_count,
        "successful": len(successful_apis),
        "found_apis": successful_apis
    }, f, indent=2, ensure_ascii=False)

print("\n💾 Részletes eredmény: api_variation_test_results.json")
