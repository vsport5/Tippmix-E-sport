# categorize_apis.py
# API-k csoportosítása kategóriák szerint

import re
from collections import defaultdict

def categorize_api(url):
    """API kategorizálása típus szerint"""
    categories = []
    
    # Video streaming
    if re.search(r'\.m3u8', url, re.I):
        categories.append('video_playlist')
    elif re.search(r'\.ts', url, re.I):
        categories.append('video_segment')
    
    # Odds (szorzók)
    if re.search(r'match_odds', url, re.I):
        categories.append('odds')
    
    # Team statistics
    if re.search(r'stats_.*team.*lastx', url, re.I):
        categories.append('team_stats_last')
    elif re.search(r'stats_.*team.*versus', url, re.I):
        categories.append('team_h2h')
    
    # Event/Match feeds
    if re.search(r'fullfeed', url, re.I):
        categories.append('full_feed')
    elif re.search(r'livescore', url, re.I):
        categories.append('livescore')
    elif re.search(r'eventIds', url, re.I):
        categories.append('event_ids')
    
    # Widgets
    if re.search(r'vswidgets', url, re.I):
        categories.append('widget')
    
    # Configuration/Settings
    if re.search(r'settings', url, re.I):
        categories.append('settings')
    elif re.search(r'competitions', url, re.I):
        categories.append('competitions')
    elif re.search(r'phases', url, re.I):
        categories.append('phases')
    elif re.search(r'timings', url, re.I):
        categories.append('timings')
    
    # Tables/Standings
    if re.search(r'table|standing', url, re.I):
        categories.append('table')
    
    # Sportradar
    if re.search(r'sportradar|sir\.sportradar', url, re.I):
        categories.append('sportradar')
    
    # Analytics
    if re.search(r'piwik|analytics', url, re.I):
        categories.append('analytics')
    
    # Templates
    if re.search(r'template', url, re.I):
        categories.append('template')
    
    # Jersey
    if re.search(r'jersey', url, re.I):
        categories.append('jersey')
    
    # Player
    if re.search(r'player', url, re.I):
        categories.append('player')
    
    # Egyéb
    if not categories:
        categories.append('other')
    
    return categories

def extract_unique_pattern(url):
    """Egyedi minta kinyerése - eltávolítja a változó részeket"""
    # Video segments numerikus részét eltávolítjuk
    url = re.sub(r'media_\d+\.ts', 'media_{N}.ts', url)
    
    # Match ID-kat generalizáljuk
    url = re.sub(r'/\d{10,}', '/{MATCH_ID}', url)
    
    # Team ID-kat generalizáljuk
    url = re.sub(r'/\d{6}/', '/{TEAM_ID}/', url)
    
    # Season ID-kat generalizáljuk
    url = re.sub(r'/\d{7}/', '/{SEASON_ID}/', url)
    
    return url

def main():
    # API-k beolvasása
    with open('deep_betting_apis.txt', 'r', encoding='utf-8') as f:
        all_apis = [line.strip() for line in f if line.strip() and not line.startswith('data:')]
    
    print(f"📊 Összesen {len(all_apis)} API beolvasva")
    
    # Kategorizálás
    categorized = defaultdict(list)
    unique_patterns = defaultdict(set)
    
    for api in all_apis:
        cats = categorize_api(api)
        for cat in cats:
            categorized[cat].append(api)
            pattern = extract_unique_pattern(api)
            unique_patterns[cat].add(pattern)
    
    # Markdown generálás
    output = []
    output.append("# 🔗 MÉLYÍTETT API VÉGPONTOK - KATEGORIZÁLT LISTA")
    output.append("")
    output.append(f"**Teljes scan idő:** 10 perc")
    output.append(f"**Összesen API-k:** {len(all_apis)}")
    output.append(f"**Kategóriák száma:** {len(categorized)}")
    output.append("")
    output.append("---")
    output.append("")
    
    # Kategóriák rendezése
    category_names = {
        'odds': '🎯 FOGADÁSI SZORZÓK (ODDS)',
        'team_stats_last': '📊 CSAPAT STATISZTIKÁK (Utolsó mérkőzések)',
        'team_h2h': '⚔️ HEAD-TO-HEAD (Egymás elleni)',
        'full_feed': '🔥 TELJES MÉRKŐZÉS FEED',
        'livescore': '⚡ ÉLŐ EREDMÉNYEK',
        'event_ids': '🆔 MÉRKŐZÉS AZONOSÍTÓK',
        'settings': '⚙️ BEÁLLÍTÁSOK',
        'competitions': '🏆 VERSENYEK / SZEZONOK',
        'phases': '📅 MÉRKŐZÉS FÁZISOK',
        'timings': '⏰ IDŐZÍTÉSEK',
        'table': '📈 TABELLA / ÁLLÁSOK',
        'widget': '📺 WIDGET API-K',
        'video_playlist': '🎬 VIDEÓ PLAYLIST',
        'video_segment': '🎥 VIDEÓ SZEGMENSEK',
        'sportradar': '🏅 SPORTRADAR API',
        'analytics': '📈 ANALYTICS / TRACKING',
        'template': '🎨 TEMPLATE',
        'jersey': '👕 MEZEK',
        'player': '🎮 PLAYER',
        'other': '📦 EGYÉB'
    }
    
    # Prioritási sorrend
    priority_order = [
        'odds', 'team_stats_last', 'team_h2h', 'full_feed', 'livescore',
        'event_ids', 'competitions', 'timings', 'phases', 'settings',
        'table', 'widget', 'sportradar', 'video_playlist', 'analytics',
        'jersey', 'player', 'template', 'video_segment', 'other'
    ]
    
    for cat in priority_order:
        if cat not in categorized:
            continue
        
        apis = categorized[cat]
        patterns = unique_patterns[cat]
        
        output.append(f"## {category_names.get(cat, cat.upper())}")
        output.append("")
        output.append(f"**Találatok száma:** {len(apis)}")
        output.append(f"**Egyedi minták:** {len(patterns)}")
        output.append("")
        
        # Ha túl sok API van (pl. video segments), csak mintákat mutatunk
        if len(apis) > 50 and cat in ['video_segment']:
            output.append(f"**Minta URL-ek (a teljes {len(apis)} közül):**")
            output.append("")
            for i, pattern in enumerate(sorted(patterns)[:5], 1):
                output.append(f"{i}. `{pattern}`")
            output.append("")
            output.append(f"... és még {len(apis) - 5} hasonló URL")
        else:
            # Egyedi minták listázása
            if len(patterns) <= 20:
                for i, pattern in enumerate(sorted(patterns), 1):
                    output.append(f"{i}. {pattern}")
            else:
                # Csak az első 20-at mutatjuk
                for i, pattern in enumerate(sorted(patterns)[:20], 1):
                    output.append(f"{i}. {pattern}")
                output.append("")
                output.append(f"... és még {len(patterns) - 20} minta")
        
        output.append("")
        output.append("---")
        output.append("")
    
    # Összefoglaló táblázat
    output.append("## 📊 ÖSSZEFOGLALÓ TÁBLÁZAT")
    output.append("")
    output.append("| Kategória | API-k száma | Egyedi minták |")
    output.append("|-----------|-------------|---------------|")
    
    for cat in priority_order:
        if cat not in categorized:
            continue
        name = category_names.get(cat, cat).replace('🎯 ', '').replace('📊 ', '').replace('⚔️ ', '').replace('🔥 ', '').replace('⚡ ', '').replace('🆔 ', '').replace('⚙️ ', '').replace('🏆 ', '').replace('📅 ', '').replace('⏰ ', '').replace('📈 ', '').replace('📺 ', '').replace('🎬 ', '').replace('🎥 ', '').replace('🏅 ', '').replace('📦 ', '').replace('👕 ', '').replace('🎮 ', '').replace('🎨 ', '')
        output.append(f"| {name} | {len(categorized[cat])} | {len(unique_patterns[cat])} |")
    
    output.append("")
    output.append("---")
    output.append("")
    output.append(f"**Készítve:** 2025-10-27")
    output.append(f"**Mélyített scan:** 10 perc / 600 másodperc")
    output.append(f"**Scanner:** deep_api_scanner.py")
    
    # Mentés
    markdown_content = "\n".join(output)
    with open('MELYITETT_API_LINKEK.md', 'w', encoding='utf-8') as f:
        f.write(markdown_content)
    
    print("✅ Kategorizálás befejezve!")
    print(f"📁 Dokumentáció: MELYITETT_API_LINKEK.md")
    print("")
    print("📊 Kategória összefoglaló:")
    for cat in priority_order:
        if cat not in categorized:
            continue
        print(f"  • {category_names.get(cat, cat)}: {len(categorized[cat])} API ({len(unique_patterns[cat])} minta)")

if __name__ == "__main__":
    main()
