
# deep_analyzer.py
# MÉLYREHATÓ ELEMZŐ - Rejtett mezők és előre generált eredmények keresése
# Célja: Settlement API-k, pre-generated results, simulation seeds feltárása

import requests
import json
import time
from datetime import datetime

def analyze_competitions_api():
    """Competitions API mélyreható elemzése"""
    print("\n" + "=" * 70)
    print("🔍 1. COMPETITIONS API ELEMZÉSE")
    print("=" * 70)
    
    try:
        url = "https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh"
        response = requests.get(url, timeout=10)
        data = response.json()
        
        # Teljes JSON dump
        full_json = json.dumps(data, indent=2, ensure_ascii=False)
        
        # Gyanús kulcsszavak keresése
        suspicious_keywords = [
            'settlement', 'settled', 'resolve', 'resolved', 'outcome', 
            'result', 'predetermined', 'generated', 'simulation', 'seed',
            'random_seed', 'generator', 'fixture_result', 'match_result',
            'final_score', 'predetermined_outcome', 'internal_result',
            '_result', '_outcome', '_settlement', '_resolved', '_seed',
            'admin', 'internal', 'hidden', 'private', 'debug'
        ]
        
        found_keywords = []
        for keyword in suspicious_keywords:
            if keyword.lower() in full_json.lower():
                found_keywords.append(keyword)
        
        if found_keywords:
            print(f"✅ TALÁLT GYANÚS KULCSSZAVAK: {', '.join(found_keywords)}")
            print("\n📄 Releváns részletek:")
            
            # Kiírjuk a teljes JSON-t
            lines = full_json.split('\n')
            for i, line in enumerate(lines):
                for keyword in found_keywords:
                    if keyword.lower() in line.lower():
                        # Kontextus: előző 2 és következő 2 sor
                        start = max(0, i - 2)
                        end = min(len(lines), i + 3)
                        print(f"\n--- Sor {i+1} környéke ---")
                        print('\n'.join(lines[start:end]))
                        break
        else:
            print("❌ Nem találtam gyanús kulcsszavakat")
        
        # Minden mező listázása
        print("\n📋 ÖSSZES MEZŐ A COMPETITIONS API-BAN:")
        all_keys = extract_all_keys(data)
        for key in sorted(all_keys):
            print(f"   • {key}")
        
        # Mentés
        with open("competitions_full_dump.json", "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        print("\n💾 Teljes dump mentve: competitions_full_dump.json")
        
        return data
        
    except Exception as e:
        print(f"❌ Hiba: {e}")
        return None

def analyze_timings_api():
    """Timings API mélyreható elemzése"""
    print("\n" + "=" * 70)
    print("🔍 2. TIMINGS API ELEMZÉSE")
    print("=" * 70)
    
    try:
        url = "https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0"
        response = requests.get(url, timeout=10)
        data = response.json()
        
        full_json = json.dumps(data, indent=2, ensure_ascii=False)
        
        suspicious_keywords = [
            'settlement', 'resolved', 'outcome', 'result', 
            'predetermined', 'generated', 'simulation', 'seed',
            'final_score', 'match_result', 'internal', 'hidden'
        ]
        
        found_keywords = []
        for keyword in suspicious_keywords:
            if keyword.lower() in full_json.lower():
                found_keywords.append(keyword)
        
        if found_keywords:
            print(f"✅ TALÁLT GYANÚS KULCSSZAVAK: {', '.join(found_keywords)}")
        else:
            print("❌ Nem találtam gyanús kulcsszavakat")
        
        # Minden mező listázása
        print("\n📋 ÖSSZES MEZŐ A TIMINGS API-BAN:")
        all_keys = extract_all_keys(data)
        for key in sorted(all_keys):
            print(f"   • {key}")
        
        # Mentés
        with open("timings_full_dump.json", "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        print("\n💾 Teljes dump mentve: timings_full_dump.json")
        
        return data
        
    except Exception as e:
        print(f"❌ Hiba: {e}")
        return None

def analyze_full_feed_api():
    """Full Feed API TELJES elemzése - EZ A LEGFONTOSABB!"""
    print("\n" + "=" * 70)
    print("🔍 3. FULL FEED API ELEMZÉSE (LEGFONTOSABB!)")
    print("=" * 70)
    
    try:
        # Aktuális szezon és forduló lekérése
        comp_url = "https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh"
        comp_data = requests.get(comp_url, timeout=10).json()
        season_id = comp_data["next_competitions"][0]["competition_id"]
        
        time_url = "https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0"
        time_data = requests.get(time_url, timeout=10).json()
        round_nr = time_data["timings"][0]["matches"][0]["matchset_nr"]
        
        print(f"📍 Aktuális szezon: {season_id}, Forduló: {round_nr}")
        
        # Full feed lekérése
        feed_url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{season_id}/{round_nr}"
        print(f"🌐 URL: {feed_url}")
        
        response = requests.get(feed_url, timeout=15)
        data = response.json()
        
        full_json = json.dumps(data, indent=2, ensure_ascii=False)
        
        print(f"\n📊 JSON méret: {len(full_json)} karakter ({len(full_json) // 1024} KB)")
        
        # MINDEN LEHETSÉGES gyanús kulcsszó
        suspicious_keywords = [
            # Settlement/Result mezők
            'settlement', 'settled', 'settle', 'resolve', 'resolved',
            'outcome', 'result', 'final_result', 'match_result', 
            'final_score', 'predetermined_outcome',
            
            # Generálás/Szimuláció
            'predetermined', 'pregenerated', 'generated', 'generate',
            'simulation', 'simulate', 'simulated', 'seed', 'random_seed',
            'generator', 'rng', 'random_number', 'fixture_result',
            
            # Belső/Rejtett
            'internal', 'internal_result', 'hidden', 'hidden_result',
            'private', 'admin', 'debug', 'test', 'metadata',
            
            # Időbélyegek
            'generated_at', 'predetermined_at', 'settled_at',
            'resolved_at', 'result_timestamp',
            
            # Egyéb gyanús
            'winner', 'winner_id', 'loser', 'loser_id',
            'final_home_score', 'final_away_score',
            'match_winner', 'predetermined_winner'
        ]
        
        found_keywords = []
        for keyword in suspicious_keywords:
            if keyword.lower() in full_json.lower():
                found_keywords.append(keyword)
        
        if found_keywords:
            print(f"\n🚨 TALÁLT {len(found_keywords)} GYANÚS KULCSSZÓ:")
            for kw in found_keywords:
                print(f"   ✅ {kw}")
            
            print("\n📄 RELEVÁNS JSON RÉSZLETEK:")
            lines = full_json.split('\n')
            shown_lines = set()
            
            for i, line in enumerate(lines):
                for keyword in found_keywords:
                    if keyword.lower() in line.lower() and i not in shown_lines:
                        # Kontextus
                        start = max(0, i - 3)
                        end = min(len(lines), i + 4)
                        
                        print(f"\n--- Kulcsszó: '{keyword}' (sor {i+1}) ---")
                        for j in range(start, end):
                            if j == i:
                                print(f">>> {lines[j]}")  # Kiemeljük
                            else:
                                print(f"    {lines[j]}")
                            shown_lines.add(j)
                        break
        else:
            print("\n❌ Nem találtam semmilyen gyanús kulcsszót")
        
        # ÖSSZES MEZŐ listázása rekurzívan
        print("\n📋 ÖSSZES MEZŐ A FULL FEED API-BAN:")
        all_keys = extract_all_keys(data)
        print(f"   Összesen {len(all_keys)} különböző mező\n")
        for key in sorted(all_keys):
            print(f"   • {key}")
        
        # Mentés
        with open("full_feed_dump.json", "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        print("\n💾 Teljes dump mentve: full_feed_dump.json")
        
        return data, found_keywords
        
    except Exception as e:
        print(f"❌ Hiba: {e}")
        return None, []

def analyze_widget_apis():
    """Widget API-k elemzése - matchProbabilities és resolvedmarkets"""
    print("\n" + "=" * 70)
    print("🔍 4. WIDGET API-K ELEMZÉSE")
    print("=" * 70)
    
    widget_apis = [
        ("Match Probabilities", "https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.data.matchProbabilities/vswidgets/"),
        ("Resolved Markets", "https://vsw.live.vsports.cloud/ls/vswidgets/?/scigamingscigamingcdn/zh/components/vswidgets.core.resolvedmarkets/vswidgets/"),
    ]
    
    results = {}
    
    for name, url in widget_apis:
        print(f"\n🔍 {name}:")
        print(f"   URL: {url}")
        
        try:
            response = requests.get(url, timeout=10)
            
            # Lehet, hogy nem JSON
            try:
                data = response.json()
                results[name] = data
                
                print(f"   ✅ Válasz érkezett (JSON)")
                print(f"   Méret: {len(json.dumps(data))} karakter")
                
                # Mentés
                filename = f"widget_{name.lower().replace(' ', '_')}.json"
                with open(filename, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                print(f"   💾 Mentve: {filename}")
                
            except:
                # Nem JSON, de van válasz
                results[name] = response.text
                print(f"   ⚠️  Válasz érkezett (nem JSON)")
                print(f"   Méret: {len(response.text)} karakter")
                print(f"   Első 200 karakter: {response.text[:200]}")
                
        except Exception as e:
            print(f"   ❌ Hiba: {e}")
            results[name] = None
    
    return results

def extract_all_keys(obj, prefix=""):
    """Rekurzívan kinyeri az összes kulcsot egy JSON objektumból"""
    keys = set()
    
    if isinstance(obj, dict):
        for key, value in obj.items():
            full_key = f"{prefix}.{key}" if prefix else key
            keys.add(full_key)
            keys.update(extract_all_keys(value, full_key))
    elif isinstance(obj, list) and obj:
        keys.update(extract_all_keys(obj[0], prefix))
    
    return keys

def analyze_timestamps():
    """Időbélyegek elemzése - van-e gyanús minta?"""
    print("\n" + "=" * 70)
    print("🔍 5. IDŐBÉLYEGEK ELEMZÉSE")
    print("=" * 70)
    
    try:
        # Lekérjük a timings API-t többször
        print("⏱️  Timings API lekérése 5 alkalommal (10s késleltetéssel)...")
        
        timestamps_data = []
        
        for i in range(5):
            url = "https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0"
            response = requests.get(url, timeout=10)
            data = response.json()
            
            current_time = datetime.now()
            timestamps_data.append({
                "request_time": current_time.isoformat(),
                "data": data
            })
            
            print(f"   {i+1}/5 - {current_time.strftime('%H:%M:%S')}")
            
            if i < 4:
                time.sleep(10)
        
        # Elemzés
        print("\n📊 IDŐBÉLYEGEK ÖSSZEHASONLÍTÁSA:")
        
        for i, entry in enumerate(timestamps_data, 1):
            matches = entry["data"]["timings"][0]["matches"]
            print(f"\n   Lekérés #{i} ({entry['request_time']}):")
            for match in matches[:3]:  # Első 3 meccs
                print(f"      Match ID: {match['id']}")
                print(f"         Start: {match['match_start_datetime']}")
                print(f"         Betstop: {match['betstop_datetime']}")
        
        # Mentés
        with open("timestamps_analysis.json", "w", encoding="utf-8") as f:
            json.dump(timestamps_data, f, indent=2, ensure_ascii=False)
        print("\n💾 Időbélyeg elemzés mentve: timestamps_analysis.json")
        
    except Exception as e:
        print(f"❌ Hiba: {e}")

def main():
    print("=" * 70)
    print("🔬 DEEP ANALYZER - Rejtett adatok és settlement API-k keresése")
    print("=" * 70)
    print("Célja: Megtalálni BÁRMILYEN jelet arra, hogy az eredmények előre generáltak\n")
    
    start_time = time.time()
    
    # 1. Competitions API
    comp_data = analyze_competitions_api()
    
    # 2. Timings API
    time_data = analyze_timings_api()
    
    # 3. Full Feed API (LEGFONTOSABB!)
    feed_data, found_keywords = analyze_full_feed_api()
    
    # 4. Widget API-k
    widget_data = analyze_widget_apis()
    
    # 5. Időbélyegek elemzése
    analyze_timestamps()
    
    # ÖSSZEFOGLALÓ
    elapsed = time.time() - start_time
    
    print("\n" + "=" * 70)
    print("📊 VÉGLEGES ÖSSZEFOGLALÓ")
    print("=" * 70)
    
    if found_keywords:
        print(f"\n🚨 TALÁLT GYANÚS KULCSSZAVAK ({len(found_keywords)} db):")
        for kw in found_keywords:
            print(f"   • {kw}")
        print("\n⚠️  TOVÁBBI VIZSGÁLAT SZÜKSÉGES!")
        print("   Nézd meg a full_feed_dump.json fájlt részletesen!")
    else:
        print("\n✅ Nem találtam egyértelmű jelet előre generált eredményekre")
        print("   (settlement, predetermined, seed, stb. kulcsszavak hiányoznak)")
    
    print("\n📁 MENTETT FÁJLOK:")
    print("   • competitions_full_dump.json")
    print("   • timings_full_dump.json")
    print("   • full_feed_dump.json")
    print("   • timestamps_analysis.json")
    print("   • widget_*.json (ha sikerült)")
    
    print(f"\n⏱️  Futási idő: {elapsed:.1f} másodperc")
    print("\n✅ DEEP ANALYSIS BEFEJEZVE!")

if __name__ == "__main__":
    main()
